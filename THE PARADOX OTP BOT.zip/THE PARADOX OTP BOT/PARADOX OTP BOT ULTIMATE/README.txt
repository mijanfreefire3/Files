[ How To Setup 📄 ]

1. Install Python 3.x if not already installed.
2. Open CMD inside this folder.
3. Run: pip install -r requirements.txt
4. Run: python main.py

Manual Login required! After login, SMS will be auto forwarded to Telegram every 2 seconds.

Developed by: @jisansheikh