"""
SMS Message Forwarder - Final Working Version
With Bangladesh Time (UTC+6) and Error Fixes
"""

from bs4 import BeautifulSoup
import requests
from datetime import datetime, timedelta
import re
import traceback
import time
import config
from selenium.webdriver.remote.webdriver import WebDriver

# Global variables
last_messages = set()

# Country to flag emoji mapping
COUNTRY_FLAGS = {
    'afghanistan': '🇦🇫',
    'bangladesh': '🇧🇩',
    'pakistan': '🇵🇰',
    'morocco': '🇲🇦',
    'venezuela': '🇻🇪',
    'saudi arabia': '🇸🇦',
    'egypt': '🇪🇬',
    'sudan': '🇸🇩',
    'uzbekistan': '🇺🇿',
    'kenya': '🇰🇪',
    'usa': '🇺🇸',
    'uk': '🇬🇧',
    'india': '🇮🇳',
    'russia': '🇷🇺',
    'turkey': '🇹🇷',
    'mali': '🇲🇱',
    'default': '🌐'
}

def validate_telegram_access():
    """Check if bot can send messages to the group"""
    url = f"https://api.telegram.org/bot{config.BOT_TOKEN}/getChat"
    payload = {"chat_id": config.CHAT_ID}
    try:
        response = requests.post(url, json=payload)
        if response.json().get('result', {}).get('permissions', {}).get('can_send_messages', True) is False:
            raise PermissionError("Bot cannot send messages in this group")
        return True
    except Exception as e:
        print(f"[TG] ❌ Access check failed: {e}")
        return False

def send_to_telegram(message: str) -> bool:
    """Send message to Telegram bot with enhanced error handling"""
    url = f"https://api.telegram.org/bot{config.BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": config.CHAT_ID,
        "text": message,
        "parse_mode": "HTML",
        "disable_web_page_preview": True
    }
    try:
        response = requests.post(url, json=payload, timeout=10)
        response.raise_for_status()
        print("[TG] ✅ Message sent successfully")
        return True
    except requests.exceptions.HTTPError as e:
        error_msg = f"[TG] ❌ HTTP Error {e.response.status_code}"
        if e.response.status_code == 400:
            error_msg += " (Bad Request - check group permissions)"
        print(error_msg)
        print(f"Response: {e.response.text}")
    except Exception as e:
        print(f"[TG] ❌ Error: {str(e)}")
    return False

def detect_otp(message: str) -> str:
    """Enhanced OTP detection with multiple pattern matching"""
    if not message:
        return "Not found"
    
    patterns = [
        r'\b\d{4,8}\b',
        r'\b\d{3}[- ]?\d{3}\b',
        r'\b\d{4}[- ]?\d{4}\b',
        r'(?i)(code|otp|codigo)[: ]*(\d{4,8})',
        r'(?i)(code|otp)[: ]*([A-Z0-9]{4,8})',
        r'\b\d{3}[- ]?\d{2}[- ]?\d{3}\b',
        r'(?<!\d)\d{4,8}(?!\d)'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, message)
        if match:
            return match.group(2) if len(match.groups()) > 1 else match.group()
    
    return "Not found"

def detect_country(phone_number: str, raw_message: str = "") -> str:
    """Country detection with message analysis fallback"""
    if not phone_number or phone_number == "Unknown":
        return "Unknown"
    
    clean_num = re.sub(r'[^\d]', '', str(phone_number))
    
    prefixes = {
        '254': 'Kenya',
        '998': 'Uzbekistan',
        '58': 'Venezuela',
        '966': 'Saudi Arabia',
        '91': 'India',
        '92': 'Pakistan',
        '1': 'USA',
        '44': 'UK',
        '7': 'Russia',
        '90': 'Turkey',
        '93': 'Afghanistan',
        '880': 'Bangladesh',
        '212': 'Morocco',
        '20': 'Egypt',
        '223': 'Mali',
        '249': 'Sudan'
    }
    
    for prefix, country in prefixes.items():
        if clean_num.startswith(prefix):
            return country
    
    if raw_message:
        raw_message_lower = raw_message.lower()
        if 'kenya' in raw_message_lower:
            return 'Kenya'
        elif 'venezuela' in raw_message_lower:
            return 'Venezuela'
        elif 'saudi' in raw_message_lower or 'arabia' in raw_message_lower:
            return 'Saudi Arabia'
        elif 'uzbekistan' in raw_message_lower:
            return 'Uzbekistan'
        elif 'russia' in raw_message_lower or 'россия' in raw_message_lower:
            return 'Russia'
    
    return 'Unknown'

def extract_sms(driver: WebDriver) -> bool:
    """Extract and forward new SMS messages with empty message filtering"""
    global last_messages
    
    try:
        print("\n[*] Loading SMS page...")
        driver.get(config.SMS_URL)
        time.sleep(3)
        
        # Get current Bangladesh time (UTC+6)
        bd_time = datetime.utcnow() + timedelta(hours=6)
        
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        
        headers = []
        for th in soup.find_all('th'):
            header = th.get('aria-label', '').lower() or th.get_text(strip=True).lower()
            if header and 'activate' not in header:
                headers.append(header)
        
        date_idx = headers.index('date') if 'date' in headers else 0
        number_idx = headers.index('number') if 'number' in headers else 2
        service_idx = headers.index('cli') if 'cli' in headers else 3
        sms_idx = headers.index('sms') if 'sms' in headers else 4

        rows = soup.find_all('tr')[1:]
        valid_messages = 0
        
        for row in rows:
            cols = row.find_all('td')
            if len(cols) <= max(date_idx, number_idx, service_idx, sms_idx):
                continue
                
            date = cols[date_idx].get_text(strip=True)
            number = cols[number_idx].get_text(strip=True) or "Unknown"
            service = cols[service_idx].get_text(strip=True) or "Unknown"
            raw_message = cols[sms_idx].get_text(strip=True)
            
            # Skip empty/invalid messages
            if (number == "0" and service == "0" and raw_message.strip() in ("0", "")) or \
               len(raw_message.strip()) < 3:
                print(f"[-] Skipping empty message from {number}")
                continue
                
            msg_id = f"{date}|{number}|{raw_message[:50]}"
            
            if msg_id not in last_messages:
                print(f"[+] New message from {number}")
                last_messages.add(msg_id)
                valid_messages += 1
                
                otp_code = detect_otp(raw_message)
                country = detect_country(number, raw_message)
                flag = COUNTRY_FLAGS.get(country.lower(), COUNTRY_FLAGS['default'])
                
                formatted = f"""
✨ <b>{flag} {country} {service} OTP Received...👀</b>

📌 <b>Your OTP:</b> <code>{otp_code}</code>  

🕒 <b>Time:</b> <code>{bd_time.strftime('%Y-%m-%d %H:%M:%S')}</code>  
📱 <b>Service:</b> <code>{service}</code>  
🌏 <b>Country:</b> <code>{country}</code> {flag}  
📞 <b>Number:</b> <code>{number}</code>  

💬 <b>Full Message:</b>  
<pre>{raw_message}</pre>  

━━━━━━━━━━━━  
👤 <b>Owner:</b> @jisansheikh  
⏰ <b>Bangladesh Time:</b> {bd_time.strftime('%I:%M %p')}
"""
                if not send_to_telegram(formatted.strip()):
                    print("[!] Retrying in 5 seconds...")
                    time.sleep(5)
                    send_to_telegram(formatted.strip())
        
        print(f"[*] Forwarded {valid_messages} valid messages")
        return True
        
    except Exception as e:
        print(f"[ERR] Extraction error: {str(e)}")
        traceback.print_exc()
        return False

if __name__ == "__main__":
    from selenium import webdriver
    driver = webdriver.Chrome()
    try:
        validate_telegram_access()
        while True:
            extract_sms(driver)
            time.sleep(5)
    except KeyboardInterrupt:
        print("\n[*] Stopped by user")
    except Exception as e:
        print(f"[!] Critical error: {str(e)}")
    finally:
        driver.quit()