BOT_TOKEN = "7549701351:AAE9csmFjw6uoPGJFkBuv5kX4BFhWrimHus"
CHAT_ID = "-1002579822648" 

LOGIN_URL = "http://109.236.84.81/ints/login"
SMS_URL = "http://109.236.84.81/ints/client/SMSCDRStats"