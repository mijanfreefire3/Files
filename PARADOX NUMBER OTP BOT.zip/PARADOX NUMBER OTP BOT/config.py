BOT_TOKEN = "8629869690:AAFz1QorrplKq8zfpDLYYFY41NaW0KhtllU"
CHAT_ID = "-1003183770922" 

LOGIN_URL = "http://51.89.99.105/NumberPanel/login"
SMS_URL = "http://51.89.99.105/NumberPanel/client/SMSCDRStats"