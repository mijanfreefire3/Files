BOT_TOKEN = "7549701351:AAE9csmFjw6uoPGJFkBuv5kX4BFhWrimHus"
CHAT_ID = "-1002579822648" 

LOGIN_URL = "https://www.konektapremium.net/sign-in"
SMS_URL = "https://www.konektapremium.net/client/SMSCDRStats"