BOT_TOKEN = "8629869690:AAFz1QorrplKq8zfpDLYYFY41NaW0KhtllU"
CHAT_ID = "-1003183770922" 

LOGIN_URL = "https://pscall.net/login"
SMS_URL = "https://pscall.net/client/SMSCDRStats"