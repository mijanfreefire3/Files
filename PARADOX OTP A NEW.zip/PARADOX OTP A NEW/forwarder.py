"""
SMS Message Forwarder - FINAL PRO VERSION
Auto Country + Flag + Masked Number
"""

from bs4 import BeautifulSoup
import requests
from datetime import datetime, timedelta
import re
import traceback
import time
import config
import phonenumbers
from phonenumbers import geocoder
from selenium.webdriver.remote.webdriver import WebDriver

# Global variables
last_messages = set()

# 🔒 Dynamic Mask Function
def mask_number(number):
    number = re.sub(r'[^\d]', '', str(number))
    n = len(number)

    if n < 7:
        return number

    start = max(2, n // 2 - 2)
    end = min(n - 2, n // 2 + 2)

    return number[:start] + "PDX" + number[end:]

# 🌍 Auto Country + Flag
def detect_country_and_flag(number):
    try:
        clean_number = re.sub(r'[^\d+]', '', str(number))

        if not clean_number.startswith('+'):
            clean_number = '+' + clean_number

        parsed = phonenumbers.parse(clean_number, None)

        country = geocoder.description_for_number(parsed, "en")

        region = phonenumbers.region_code_for_number(parsed)

        if region:
            flag = ''.join(chr(127397 + ord(c)) for c in region)
        else:
            flag = "🌐"

        return country if country else "Unknown", flag

    except:
        return "Unknown", "🌐"

# 📩 Telegram send
def send_to_telegram(message: str) -> bool:
    url = f"https://api.telegram.org/bot{config.BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": config.CHAT_ID,
        "text": message,
        "parse_mode": "HTML",
        "disable_web_page_preview": True
    }
    try:
        response = requests.post(url, json=payload, timeout=10)
        response.raise_for_status()
        print("[TG] ✅ Sent")
        return True
    except Exception as e:
        print(f"[TG] ❌ {e}")
        return False

# 🔍 OTP detect
def detect_otp(message: str) -> str:
    if not message:
        return "Not found"

    patterns = [
        r'\b\d{4,8}\b',
        r'\b\d{3}[- ]?\d{3}\b',
        r'(?i)(code|otp)[: ]*(\d{4,8})'
    ]

    for pattern in patterns:
        match = re.search(pattern, message)
        if match:
            return match.group(2) if len(match.groups()) > 1 else match.group()

    return "Not found"

# 📥 Main extractor
def extract_sms(driver: WebDriver):
    global last_messages

    try:
        driver.get(config.SMS_URL)
        time.sleep(3)

        bd_time = datetime.utcnow() + timedelta(hours=6)
        soup = BeautifulSoup(driver.page_source, 'html.parser')

        rows = soup.find_all('tr')[1:]

        for row in rows:
            cols = row.find_all('td')
            if len(cols) < 5:
                continue

            date = cols[0].get_text(strip=True)
            number = cols[2].get_text(strip=True) or "Unknown"
            service = cols[3].get_text(strip=True) or "Unknown"
            raw_message = cols[7].get_text(strip=True)

            if len(raw_message.strip()) < 3:
                continue

            msg_id = f"{date}|{number}|{raw_message[:50]}"

            if msg_id not in last_messages:
                last_messages.add(msg_id)

                otp_code = detect_otp(raw_message)

                # 🌍 Auto detect
                country, flag = detect_country_and_flag(number)

                # 🔒 Mask number
                masked_number = mask_number(number)

                formatted = f"""
✨ <b>{flag} {country} {service} OTP Received...👀</b>

📌 <b>Your OTP:</b> <code>{otp_code}</code>  

🕒 <b>Time:</b> <code>{bd_time.strftime('%Y-%m-%d %H:%M:%S')}</code>  
📱 <b>Service:</b> <code>{service}</code>  
🌏 <b>Country:</b> <code>{country}</code> {flag}  
📞 <b>Number:</b> <code>{masked_number}</code>  

💬 <b>Full Message:</b>  
<pre>{raw_message}</pre>  
━━━━━━━━━━━━    
⏰ <b>Bangladesh Time:</b> {bd_time.strftime('%I:%M %p')}
"""

                send_to_telegram(formatted.strip())

    except Exception as e:
        print("Error:", e)
        traceback.print_exc()

# ▶️ Run
if __name__ == "__main__":
    from selenium import webdriver
    driver = webdriver.Chrome()

    while True:
        extract_sms(driver)
        time.sleep(5)