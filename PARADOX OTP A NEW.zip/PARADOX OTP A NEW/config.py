BOT_TOKEN = "8629869690:AAFz1QorrplKq8zfpDLYYFY41NaW0KhtllU"
CHAT_ID = "-1003183770922" 

LOGIN_URL = "http://51.255.80.7/sms/SignIn"
SMS_URL = "http://51.255.80.7/sms/subclient/Reports"