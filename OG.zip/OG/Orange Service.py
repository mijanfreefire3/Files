import telebot
from telebot.types import *
import sqlite3
import time
import threading
import logging
from datetime import datetime

# ================= CONFIG ================= #
BOT_TOKEN = "8534858301:AAFSDBBImHGjlWoq73Up1khezTF00YSHyVE"
SUPER_ADMIN = 5556053750  # তোমার Telegram ID

# লগিং সেটআপ
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

bot = telebot.TeleBot(BOT_TOKEN)

# ================= DATABASE ================= #
class Database:
    def __init__(self):
        self.connection = sqlite3.connect("orange_bot.db", check_same_thread=False)
        self.cursor = self.connection.cursor()
        self.create_tables()
        self.lock = threading.Lock()
    
    def create_tables(self):
        with self.lock:
            self.cursor.execute("""
                CREATE TABLE IF NOT EXISTS users(
                    user_id INTEGER PRIMARY KEY, 
                    balance REAL DEFAULT 0,
                    username TEXT,
                    full_name TEXT,
                    join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            self.cursor.execute("""
                CREATE TABLE IF NOT EXISTS admins(
                    user_id INTEGER PRIMARY KEY,
                    added_by INTEGER,
                    added_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            self.cursor.execute("""
                CREATE TABLE IF NOT EXISTS recharge(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    amount REAL,
                    status TEXT DEFAULT 'Pending',
                    file_id TEXT,
                    request_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    process_time TIMESTAMP,
                    processed_by INTEGER
                )
            """)
            self.cursor.execute("""
                CREATE TABLE IF NOT EXISTS services(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    email TEXT,
                    username TEXT,
                    bot_username TEXT,
                    chat_id TEXT,
                    status TEXT DEFAULT 'Pending',
                    start_time INTEGER,
                    end_time INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            # নতুন টেবিল: ব্রডকাস্ট লগ
            self.cursor.execute("""
                CREATE TABLE IF NOT EXISTS broadcasts(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sent_by INTEGER,
                    message TEXT,
                    success_count INTEGER DEFAULT 0,
                    fail_count INTEGER DEFAULT 0,
                    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            self.connection.commit()

db = Database()

# ================= BASIC FUNCTIONS ================= #
def add_user(user_id, username=None, full_name=None):
    try:
        with db.lock:
            db.cursor.execute(
                "INSERT OR IGNORE INTO users(user_id, username, full_name) VALUES(?, ?, ?)",
                (user_id, username, full_name)
            )
            db.connection.commit()
    except Exception as e:
        logger.error(f"Error adding user: {e}")

def get_balance(user_id):
    try:
        with db.lock:
            db.cursor.execute("SELECT balance FROM users WHERE user_id=?", (user_id,))
            result = db.cursor.fetchone()
            return result[0] if result else 0
    except Exception as e:
        logger.error(f"Error getting balance: {e}")
        return 0

def update_balance(user_id, amount):
    try:
        current_balance = get_balance(user_id)
        new_balance = current_balance + amount
        
        if new_balance < 0:
            return False, "Insufficient balance"
            
        with db.lock:
            db.cursor.execute(
                "UPDATE users SET balance=? WHERE user_id=?",
                (new_balance, user_id)
            )
            db.connection.commit()
        return True, "Balance updated successfully"
    except Exception as e:
        logger.error(f"Error updating balance: {e}")
        return False, "Database error"

def is_admin(user_id):
    try:
        if user_id == SUPER_ADMIN:
            return True
        with db.lock:
            db.cursor.execute("SELECT user_id FROM admins WHERE user_id=?", (user_id,))
            return db.cursor.fetchone() is not None
    except Exception as e:
        logger.error(f"Error checking admin: {e}")
        return False

# ================= START ================= #
@bot.message_handler(commands=['start'])
def start(msg):
    try:
        user_id = msg.from_user.id
        username = msg.from_user.username
        full_name = f"{msg.from_user.first_name} {msg.from_user.last_name or ''}".strip()
        
        add_user(user_id, username, full_name)
        
        kb = InlineKeyboardMarkup(row_width=2)
        kb.add(
            InlineKeyboardButton("📊 Dashboard", callback_data="dashboard"),
            InlineKeyboardButton("🛒 Buy Service", callback_data="buy")
        )
        kb.add(
            InlineKeyboardButton("💰 Recharge", callback_data="recharge"),
            InlineKeyboardButton("ℹ️ Help", callback_data="help")
        )
        
        if is_admin(user_id):
            kb.add(InlineKeyboardButton("👑 Admin Panel", callback_data="admin_panel"))
        
        welcome_text = f"""
👋 Welcome {msg.from_user.first_name}!

📱 Orange Carrier Rent Bot

✨ Features:
• Rent Orange Carrier Services
• Easy Recharge System
• 24/7 Support
• Secure Payments

Use the buttons below to navigate:
        """
        
        bot.send_message(msg.chat.id, welcome_text, reply_markup=kb)
    except Exception as e:
        logger.error(f"Error in start command: {e}")
        bot.send_message(msg.chat.id, "❌ An error occurred. Please try again.")

# ================= DASHBOARD ================= #
@bot.callback_query_handler(func=lambda c: c.data == "dashboard")
def dashboard(c):
    try:
        user_id = c.from_user.id
        balance = get_balance(user_id)
        
        with db.lock:
            # অ্যাকটিভ সার্ভিস কাউন্ট
            db.cursor.execute(
                "SELECT COUNT(*) FROM services WHERE user_id=? AND status='Working'",
                (user_id,)
            )
            active_services = db.cursor.fetchone()[0]
            
            # টোটাল স্পেন্ড
            db.cursor.execute(
                "SELECT COUNT(*) FROM services WHERE user_id=? AND status='Done'",
                (user_id,)
            )
            completed_services = db.cursor.fetchone()[0]
        
        dashboard_text = f"""
📊 Your Dashboard

💰 Balance: ${balance:.2f}
🔄 Active Services: {active_services}
✅ Completed Services: {completed_services}
🆔 User ID: {user_id}

📊 Statistics:
• Total Spent: ${completed_services * 0.02:.2f}
• Available Balance: ${balance:.2f}
        """
        
        kb = InlineKeyboardMarkup()
        kb.add(InlineKeyboardButton("🔄 Refresh", callback_data="dashboard"))
        kb.add(InlineKeyboardButton("📜 Transaction History", callback_data="history"))
        
        bot.edit_message_text(
            dashboard_text,
            c.message.chat.id,
            c.message.id,
            reply_markup=kb
        )
    except Exception as e:
        logger.error(f"Error in dashboard: {e}")
        bot.answer_callback_query(c.id, "❌ Error loading dashboard")

# ================= HELP ================= #
@bot.callback_query_handler(func=lambda c: c.data == "help")
def help_command(c):
    help_text = """
ℹ️ Help & Support

📋 How to Use:
1. First, recharge your account using '💰 Recharge'
2. Buy service using '🛒 Buy Service'
3. Wait for admin approval
4. Service will start automatically

💰 Recharge Process:
1. Click '💰 Recharge'
2. Enter amount (minimum $1)
3. Send payment screenshot
4. Wait for admin approval

🛒 Buy Service:
1. Minimum balance required: $0.02
2. Fill all required information
3. Pay from your balance
4. Wait for admin to start service

⏰ Service Duration: 6 hours

👥 Support:
Contact @your_support_username for help

⚠️ Terms:
• No refund for used services
• Follow all rules
• Fraudulent activities will result in ban
    """
    
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("🔙 Back to Menu", callback_data="back_menu"))
    
    bot.edit_message_text(
        help_text,
        c.message.chat.id,
        c.message.id,
        reply_markup=kb
    )

# ================= BACK TO MENU ================= #
@bot.callback_query_handler(func=lambda c: c.data == "back_menu")
def back_to_menu(c):
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("📊 Dashboard", callback_data="dashboard"),
        InlineKeyboardButton("🛒 Buy Service", callback_data="buy")
    )
    kb.add(
        InlineKeyboardButton("💰 Recharge", callback_data="recharge"),
        InlineKeyboardButton("ℹ️ Help", callback_data="help")
    )
    
    if is_admin(c.from_user.id):
        kb.add(InlineKeyboardButton("👑 Admin Panel", callback_data="admin_panel"))
    
    bot.edit_message_text(
        "🏠 Main Menu\n\nSelect an option:",
        c.message.chat.id,
        c.message.id,
        reply_markup=kb
    )

# ================= RECHARGE ================= #
user_recharge = {}

@bot.callback_query_handler(func=lambda c: c.data == "recharge")
def recharge(c):
    try:
        text = """
💰 Recharge Your Account

Enter recharge amount in USD ($).

💳 Minimum: $1.00
💳 Maximum: $1000.00

Example: 10.50
        """
        
        msg = bot.send_message(c.message.chat.id, text)
        bot.register_next_step_handler(msg, recharge_amount)
    except Exception as e:
        logger.error(f"Error in recharge: {e}")
        bot.answer_callback_query(c.id, "❌ Error")

def recharge_amount(msg):
    try:
        user_id = msg.from_user.id
        
        # চেক যদি ইউজার আইডি সঠিক হয়
        if not isinstance(user_id, int):
            bot.send_message(msg.chat.id, "❌ Invalid user ID")
            return
        
        amount = float(msg.text)
        
        # ভ্যালিডেশন
        if amount < 1:
            bot.send_message(msg.chat.id, "❌ Minimum recharge amount is $1.00")
            return
        if amount > 1000:
            bot.send_message(msg.chat.id, "❌ Maximum recharge amount is $1000.00")
            return
        
        user_recharge[user_id] = amount
        
        instruction = f"""
✅ Amount set: ${amount:.2f}

📤 Now send payment screenshot.

⚠️ Important:
1. Screenshot must be clear
2. Include transaction ID if possible
3. Do not edit the screenshot
4. Upload as photo (not file)
        """
        
        bot.send_message(msg.chat.id, instruction)
        
    except ValueError:
        bot.send_message(msg.chat.id, "❌ Please enter a valid number (e.g., 10.50)")
    except Exception as e:
        logger.error(f"Error in recharge_amount: {e}")
        bot.send_message(msg.chat.id, "❌ An error occurred")

@bot.message_handler(content_types=['photo'])
def recharge_screenshot(msg):
    try:
        user_id = msg.from_user.id
        
        if user_id not in user_recharge:
            return
        
        amount = user_recharge[user_id]
        file_id = msg.photo[-1].file_id
        
        with db.lock:
            db.cursor.execute(
                """INSERT INTO recharge(user_id, amount, file_id) 
                VALUES(?, ?, ?)""",
                (user_id, amount, file_id)
            )
            db.connection.commit()
            rid = db.cursor.lastrowid
        
        # ইউজারকে নোটিফাই
        bot.send_message(
            user_id,
            f"✅ Recharge request submitted!\n\n"
            f"💰 Amount: ${amount:.2f}\n"
            f"🆔 Request ID: #{rid}\n"
            f"⏰ Status: Pending approval\n\n"
            f"You will be notified once approved."
        )
        
        # এডমিনদের নোটিফাই
        admin_kb = InlineKeyboardMarkup()
        admin_kb.add(
            InlineKeyboardButton("✅ Approve", callback_data=f"approve_{rid}"),
            InlineKeyboardButton("❌ Reject", callback_data=f"reject_{rid}"),
            InlineKeyboardButton("👀 View User", callback_data=f"viewuser_{user_id}")
        )
        
        # সুপার এডমিনকে সেন্ড
        bot.send_photo(
            SUPER_ADMIN,
            file_id,
            caption=f"""
💳 New Recharge Request

🆔 Request ID: #{rid}
👤 User ID: {user_id}
👤 Username: @{msg.from_user.username or 'N/A'}
💰 Amount: ${amount:.2f}
⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            """,
            reply_markup=admin_kb
        )
        
        # অন্যান্য এডমিনদেরকেও নোটিফাই (ঐচ্ছিক)
        with db.lock:
            db.cursor.execute("SELECT user_id FROM admins")
            admins = db.cursor.fetchall()
        
        for admin in admins:
            try:
                if admin[0] != SUPER_ADMIN:
                    bot.send_photo(
                        admin[0],
                        file_id,
                        caption=f"New recharge request #{rid} - ${amount:.2f}",
                        reply_markup=admin_kb
                    )
            except:
                pass
        
        del user_recharge[user_id]
        
    except Exception as e:
        logger.error(f"Error in recharge_screenshot: {e}")
        bot.send_message(msg.chat.id, "❌ An error occurred")

# ================= RECHARGE APPROVE/REJECT ================= #
@bot.callback_query_handler(func=lambda c: c.data.startswith(("approve_", "reject_", "viewuser_")))
def handle_recharge_request(c):
    try:
        user_id = c.from_user.id
        
        if not is_admin(user_id):
            bot.answer_callback_query(c.id, "❌ Admin access required")
            return
        
        action, rid = c.data.split("_")[:2]
        rid = int(rid)
        
        with db.lock:
            db.cursor.execute(
                "SELECT user_id, amount, status FROM recharge WHERE id=?",
                (rid,)
            )
            result = db.cursor.fetchone()
            
            if not result:
                bot.answer_callback_query(c.id, "❌ Request not found")
                return
                
            req_user_id, amount, status = result
            
            if status != "Pending":
                bot.answer_callback_query(c.id, f"❌ Request already {status}")
                return
        
        if action == "viewuser":
            # ইউজার ইনফো দেখাবে
            with db.lock:
                db.cursor.execute(
                    "SELECT username, balance FROM users WHERE user_id=?",
                    (req_user_id,)
                )
                user_info = db.cursor.fetchone()
            
            info_text = f"""
👤 User Information:
🆔 User ID: {req_user_id}
👤 Username: @{user_info[0] or 'N/A'}
💰 Balance: ${user_info[1]:.2f if user_info else 0}
            """
            
            bot.answer_callback_query(c.id, info_text, show_alert=True)
            return
        
        elif action == "approve":
            # ব্যালেন্স আপডেট
            success, message = update_balance(req_user_id, amount)
            
            if not success:
                bot.answer_callback_query(c.id, f"❌ {message}")
                return
            
            with db.lock:
                db.cursor.execute(
                    """UPDATE recharge SET 
                    status='Approved', 
                    process_time=CURRENT_TIMESTAMP,
                    processed_by=?
                    WHERE id=?""",
                    (user_id, rid)
                )
                db.connection.commit()
            
            # ইউজারকে নোটিফাই
            try:
                bot.send_message(
                    req_user_id,
                    f"""
✅ Recharge Approved!

💰 Amount: ${amount:.2f}
🆔 Request ID: #{rid}
📊 New Balance: ${get_balance(req_user_id):.2f}
                    """
                )
            except:
                pass
            
            bot.answer_callback_query(c.id, "✅ Recharge approved")
            
            # এডমিন মেসেজ আপডেট
            bot.edit_message_caption(
                chat_id=c.message.chat.id,
                message_id=c.message.id,
                caption=f"""
✅ Recharge Approved

🆔 Request ID: #{rid}
👤 User ID: {req_user_id}
💰 Amount: ${amount:.2f}
👮 Approved by: {user_id}
⏰ Time: {datetime.now().strftime('%H:%M:%S')}
                """,
                reply_markup=None
            )
        
        elif action == "reject":
            with db.lock:
                db.cursor.execute(
                    """UPDATE recharge SET 
                    status='Rejected',
                    process_time=CURRENT_TIMESTAMP,
                    processed_by=?
                    WHERE id=?""",
                    (user_id, rid)
                )
                db.connection.commit()
            
            # ইউজারকে নোটিফাই
            try:
                bot.send_message(
                    req_user_id,
                    f"""
❌ Recharge Rejected

💰 Amount: ${amount:.2f}
🆔 Request ID: #{rid}
ℹ️ Reason: Verification failed

Please contact support if you think this is an error.
                    """
                )
            except:
                pass
            
            bot.answer_callback_query(c.id, "❌ Recharge rejected")
            
            # এডমিন মেসেজ আপডেট
            bot.edit_message_caption(
                chat_id=c.message.chat.id,
                message_id=c.message.id,
                caption=f"""
❌ Recharge Rejected

🆔 Request ID: #{rid}
👤 User ID: {req_user_id}
💰 Amount: ${amount:.2f}
👮 Rejected by: {user_id}
⏰ Time: {datetime.now().strftime('%H:%M:%S')}
                """,
                reply_markup=None
            )
    
    except Exception as e:
        logger.error(f"Error handling recharge request: {e}")
        bot.answer_callback_query(c.id, "❌ An error occurred")

# ================= BUY SERVICE ================= #
service_data = {}

@bot.callback_query_handler(func=lambda c: c.data == "buy")
def buy_service(c):
    try:
        user_id = c.from_user.id
        balance = get_balance(user_id)
        
        if balance < 0.02:
            bot.answer_callback_query(
                c.id,
                f"❌ Insufficient balance. Required: $0.02, Available: ${balance:.2f}",
                show_alert=True
            )
            return
        
        instruction = """
🛒 Buy Service

Please provide the following information:

📧 Step 1: Orange Carrier Email
Enter the email address for Orange Carrier service.

Example: user@example.com
        """
        
        msg = bot.send_message(c.message.chat.id, instruction)
        bot.register_next_step_handler(msg, step_email)
        
    except Exception as e:
        logger.error(f"Error in buy_service: {e}")
        bot.answer_callback_query(c.id, "❌ An error occurred")

def step_email(msg):
    try:
        user_id = msg.from_user.id
        email = msg.text.strip()
        
        # বেসিক ইমেইল ভ্যালিডেশন
        if "@" not in email or "." not in email:
            bot.send_message(msg.chat.id, "❌ Please enter a valid email address")
            msg2 = bot.send_message(msg.chat.id, "Please enter Orange Carrier Email:")
            bot.register_next_step_handler(msg2, step_email)
            return
        
        service_data[user_id] = {"email": email}
        
        msg2 = bot.send_message(msg.chat.id, "👤 Step 2: Enter your Telegram username (without @):")
        bot.register_next_step_handler(msg2, step_username)
        
    except Exception as e:
        logger.error(f"Error in step_email: {e}")
        bot.send_message(msg.chat.id, "❌ An error occurred")

def step_username(msg):
    try:
        user_id = msg.from_user.id
        
        if user_id not in service_data:
            bot.send_message(msg.chat.id, "❌ Session expired. Please start again.")
            return
        
        username = msg.text.strip().replace("@", "")
        service_data[user_id]["username"] = username
        
        msg2 = bot.send_message(
            msg.chat.id,
            "🤖 Step 3: Enter your Bot username (without @):\n\nExample: mybot"
        )
        bot.register_next_step_handler(msg2, step_bot)
        
    except Exception as e:
        logger.error(f"Error in step_username: {e}")
        bot.send_message(msg.chat.id, "❌ An error occurred")

def step_bot(msg):
    try:
        user_id = msg.from_user.id
        
        if user_id not in service_data:
            bot.send_message(msg.chat.id, "❌ Session expired. Please start again.")
            return
        
        bot_username = msg.text.strip().replace("@", "")
        service_data[user_id]["bot"] = bot_username
        
        msg2 = bot.send_message(
            msg.chat.id,
            "💬 Step 4: Enter Group/Chat ID:\n\n"
            "Note: Use @getidsbot to get chat ID if you don't know"
        )
        bot.register_next_step_handler(msg2, finish_service)
        
    except Exception as e:
        logger.error(f"Error in step_bot: {e}")
        bot.send_message(msg.chat.id, "❌ An error occurred")

def finish_service(msg):
    try:
        user_id = msg.from_user.id
        
        if user_id not in service_data:
            bot.send_message(msg.chat.id, "❌ Session expired. Please start again.")
            return
        
        chat_id = msg.text.strip()
        data = service_data[user_id]
        
        # ব্যালেন্স কেটে নেয়া
        success, message = update_balance(user_id, -0.02)
        
        if not success:
            bot.send_message(msg.chat.id, f"❌ {message}")
            del service_data[user_id]
            return
        
        # সার্ভিস ক্রিয়েট করা
        with db.lock:
            db.cursor.execute("""
                INSERT INTO services(
                    user_id, email, username, 
                    bot_username, chat_id, status
                ) VALUES(?, ?, ?, ?, ?, ?)
            """, (
                user_id,
                data["email"],
                data["username"],
                data["bot"],
                chat_id,
                "Pending"
            ))
            db.connection.commit()
            sid = db.cursor.lastrowid
        
        # ইউজারকে কনফার্মেশন
        bot.send_message(
            msg.chat.id,
            f"""
✅ Service Request Submitted!

🆔 Service ID: #{sid}
📧 Email: {data['email']}
👤 Username: {data['username']}
🤖 Bot: {data['bot']}
💬 Chat ID: {chat_id}
💰 Charged: $0.02
📊 Remaining Balance: ${get_balance(user_id):.2f}

⏰ Status: Waiting for admin approval
            """
        )
        
        # এডমিন নোটিফিকেশন
        admin_kb = InlineKeyboardMarkup()
        admin_kb.add(
            InlineKeyboardButton("🚀 Start Service", callback_data=f"start_{sid}"),
            InlineKeyboardButton("👀 View User", callback_data=f"viewuser_{user_id}"),
            InlineKeyboardButton("📊 Check Balance", callback_data=f"checkbal_{user_id}")
        )
        
        with db.lock:
            db.cursor.execute(
                "SELECT username, balance FROM users WHERE user_id=?",
                (user_id,)
            )
            user_info = db.cursor.fetchone()
        
        admin_text = f"""
🛒 New Service Request

🆔 Service ID: #{sid}
👤 User: @{user_info[0] or 'N/A'} ({user_id})
💰 User Balance: ${user_info[1]:.2f if user_info else 0}

📋 Details:
📧 Email: {data['email']}
👤 Username: {data['username']}
🤖 Bot: {data['bot']}
💬 Chat ID: {chat_id}
⏰ Requested: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        """
        
        # সুপার এডমিনকে সেন্ড
        bot.send_message(SUPER_ADMIN, admin_text, reply_markup=admin_kb)
        
        # অন্যান্য এডমিনদেরকেও নোটিফাই
        with db.lock:
            db.cursor.execute("SELECT user_id FROM admins")
            admins = db.cursor.fetchall()
        
        for admin in admins:
            try:
                if admin[0] != SUPER_ADMIN:
                    bot.send_message(
                        admin[0],
                        f"New service request #{sid} from user {user_id}",
                        reply_markup=admin_kb
                    )
            except:
                pass
        
        # ক্লিন আপ
        del service_data[user_id]
        
    except Exception as e:
        logger.error(f"Error in finish_service: {e}")
        bot.send_message(msg.chat.id, "❌ An error occurred")

# ================= CHECK BALANCE (ADMIN) ================= #
@bot.callback_query_handler(func=lambda c: c.data.startswith("checkbal_"))
def check_balance_admin(c):
    try:
        if not is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "❌ Admin access required")
            return
        
        user_id = int(c.data.split("_")[1])
        balance = get_balance(user_id)
        
        with db.lock:
            db.cursor.execute(
                "SELECT username FROM users WHERE user_id=?",
                (user_id,)
            )
            username = db.cursor.fetchone()
        
        bot.answer_callback_query(
            c.id,
            f"💰 Balance of @{username[0] if username else user_id}: ${balance:.2f}",
            show_alert=True
        )
    except Exception as e:
        logger.error(f"Error in check_balance_admin: {e}")

# ================= START SERVICE (ADMIN) ================= #
@bot.callback_query_handler(func=lambda c: c.data.startswith("start_"))
def start_service_admin(c):
    try:
        if not is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "❌ Admin access required")
            return
        
        sid = int(c.data.split("_")[1])
        
        with db.lock:
            # সার্ভিস ডিটেইলস নেয়া
            db.cursor.execute(
                "SELECT user_id, status FROM services WHERE id=?",
                (sid,)
            )
            result = db.cursor.fetchone()
            
            if not result:
                bot.answer_callback_query(c.id, "❌ Service not found")
                return
            
            user_id, status = result
            
            if status != "Pending":
                bot.answer_callback_query(
                    c.id, 
                    f"❌ Service is already {status}",
                    show_alert=True
                )
                return
            
            # টাইম সেট করা
            start_time = int(time.time())
            end_time = start_time + 21600  # 6 hours
            
            db.cursor.execute(
                """UPDATE services SET 
                status='Working',
                start_time=?,
                end_time=?
                WHERE id=?""",
                (start_time, end_time, sid)
            )
            db.connection.commit()
        
        # ইউজারকে নোটিফাই
        try:
            end_time_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time))
            
            bot.send_message(
                user_id,
                f"""
🚀 Service Started!

🆔 Service ID: #{sid}
⏰ Started: {time.strftime('%Y-%m-%d %H:%M:%S')}
⏰ Will End: {end_time_str}
⏳ Duration: 6 hours

✅ Your service is now active.
                """
            )
        except:
            pass
        
        bot.answer_callback_query(c.id, "✅ Service started")
        
        # এডমিন মেসেজ আপডেট
        try:
            bot.edit_message_text(
                f"""
✅ Service Started

🆔 Service ID: #{sid}
👤 User ID: {user_id}
⏰ Started by: {c.from_user.id}
⏰ Start Time: {datetime.now().strftime('%H:%M:%S')}
⏰ Will run for 6 hours
                """,
                c.message.chat.id,
                c.message.id
            )
        except:
            pass
        
    except Exception as e:
        logger.error(f"Error in start_service_admin: {e}")
        bot.answer_callback_query(c.id, "❌ An error occurred")

# ================= ADMIN PANEL ================= #
@bot.callback_query_handler(func=lambda c: c.data == "admin_panel")
def admin_panel(c):
    try:
        if not is_admin(c.from_user.id):
            bot.answer_callback_query(c.id, "❌ Admin access required")
            return
        
        # স্ট্যাটিস্টিক্স কালেক্ট করা
        with db.lock:
            # টোটাল ইউজার
            db.cursor.execute("SELECT COUNT(*) FROM users")
            total_users = db.cursor.fetchone()[0]
            
            # টোটাল ব্যালেন্স
            db.cursor.execute("SELECT SUM(balance) FROM users")
            total_balance = db.cursor.fetchone()[0] or 0
            
            # পেন্ডিং রিচার্জ
            db.cursor.execute(
                "SELECT COUNT(*) FROM recharge WHERE status='Pending'"
            )
            pending_recharge = db.cursor.fetchone()[0]
            
            # পেন্ডিং সার্ভিস
            db.cursor.execute(
                "SELECT COUNT(*) FROM services WHERE status='Pending'"
            )
            pending_services = db.cursor.fetchone()[0]
            
            # অ্যাকটিভ সার্ভিস
            db.cursor.execute(
                "SELECT COUNT(*) FROM services WHERE status='Working'"
            )
            active_services = db.cursor.fetchone()[0]
        
        panel_text = f"""
👑 Admin Panel

📊 Statistics:
👥 Total Users: {total_users}
💰 Total Balance: ${total_balance:.2f}
⏳ Pending Recharge: {pending_recharge}
🛒 Pending Services: {pending_services}
🔄 Active Services: {active_services}

Select an option below:
        """
        
        kb = InlineKeyboardMarkup(row_width=2)
        
        kb.add(
            InlineKeyboardButton("📋 Pending Recharge", callback_data="admin_pending_recharge"),
            InlineKeyboardButton("📦 Pending Services", callback_data="admin_pending_services")
        )
        kb.add(
            InlineKeyboardButton("👥 All Users", callback_data="admin_all_users"),
            InlineKeyboardButton("📢 Broadcast", callback_data="admin_broadcast")
        )
        
        if c.from_user.id == SUPER_ADMIN:
            kb.add(
                InlineKeyboardButton("➕ Add Admin", callback_data="admin_add_admin"),
                InlineKeyboardButton("➖ Remove Admin", callback_data="admin_remove_admin")
            )
        
        kb.add(InlineKeyboardButton("🔙 Back to Menu", callback_data="back_menu"))
        
        bot.edit_message_text(
            panel_text,
            c.message.chat.id,
            c.message.id,
            reply_markup=kb
        )
        
    except Exception as e:
        logger.error(f"Error in admin_panel: {e}")
        bot.answer_callback_query(c.id, "❌ An error occurred")

@bot.callback_query_handler(func=lambda c: c.data == "admin_pending_recharge")
def admin_pending_recharge(c):
    try:
        if not is_admin(c.from_user.id):
            return
        
        with db.lock:
            db.cursor.execute("""
                SELECT r.id, r.user_id, r.amount, u.username, r.request_time
                FROM recharge r
                LEFT JOIN users u ON r.user_id = u.user_id
                WHERE r.status='Pending'
                ORDER BY r.request_time ASC
                LIMIT 10
            """)
            pending = db.cursor.fetchall()
        
        if not pending:
            text = "✅ No pending recharge requests"
        else:
            text = "📋 Pending Recharge Requests:\n\n"
            for req in pending:
                rid, uid, amount, username, req_time = req
                text += f"🆔 #{rid}\n👤 @{username or uid}\n💰 ${amount:.2f}\n⏰ {req_time[:16]}\n"
                text += "───────\n"
        
        kb = InlineKeyboardMarkup()
        kb.add(InlineKeyboardButton("🔙 Back to Admin Panel", callback_data="admin_panel"))
        
        bot.edit_message_text(
            text,
            c.message.chat.id,
            c.message.id,
            reply_markup=kb
        )
        
    except Exception as e:
        logger.error(f"Error in admin_pending_recharge: {e}")

# অন্যান্য এডমিন ফাংশনগুলিও একইভাবে ইম্প্লিমেন্ট করতে হবে...

# ================= AUTO TIMER ================= #
def service_timer():
    while True:
        try:
            now = int(time.time())
            
            with db.lock:
                # এক্সপায়ার্ড সার্ভিস খোঁজা
                db.cursor.execute(
                    "SELECT id, user_id FROM services WHERE status='Working' AND end_time < ?",
                    (now,)
                )
                expired_services = db.cursor.fetchall()
                
                for sid, uid in expired_services:
                    # স্ট্যাটাস আপডেট
                    db.cursor.execute(
                        "UPDATE services SET status='Done' WHERE id=?",
                        (sid,)
                    )
                    db.connection.commit()
                    
                    # ইউজারকে নোটিফাই
                    try:
                        bot.send_message(
                            uid,
                            f"""
✅ Service Completed

🆔 Service ID: #{sid}
⏰ Ended: {time.strftime('%Y-%m-%d %H:%M:%S')}
✅ Status: Completed successfully

Thank you for using our service!
                            """
                        )
                    except Exception as e:
                        logger.error(f"Failed to notify user {uid}: {e}")
            
            time.sleep(30)  # ৩০ সেকেন্ড পরপর চেক করে
            
        except Exception as e:
            logger.error(f"Error in service_timer: {e}")
            time.sleep(60)

# টাইমার থ্রেড শুরু করা
timer_thread = threading.Thread(target=service_timer, daemon=True)
timer_thread.start()

# ================= RUN ================= #
if __name__ == "__main__":
    logger.info("Starting Orange Carrier Bot...")
    print("""
===================================
    Orange Carrier Rent Bot
    Version: 2.0
    Status: RUNNING...
===================================
    """)
    
    try:
        bot.infinity_polling(timeout=60, long_polling_timeout=60)
    except Exception as e:
        logger.error(f"Bot crashed: {e}")
    finally:
        db.connection.close()