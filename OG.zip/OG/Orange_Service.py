[file name]: Orange_Service.py
[file content begin]
import telebot
from telebot.types import *
import sqlite3
import time
import threading
import os
from datetime import datetime

# ================= CONFIG ================= #

BOT_TOKEN = "8534858301:AAFSDBBImHGjlWoq73Up1khezTF00YSHyVE"
SUPER_ADMIN = 5556053750
SERVICE_PRICE = 0.02
SERVICE_DURATION = 21600
REMINDER_TIME = 3600  # 1 hour before expiry

# Exchange Rate
BDT_TO_USD_RATE = 125  # 125 TK = 1$

# Payment Methods
PAYMENT_METHODS = {
    "bkash": {
        "name": "bKash", 
        "number": "01770530491", 
        "fee": 0,
        "type": "mobile",
        "min_amount": 0.20,
        "currency": "BDT"
    },
    "nagad": {
        "name": "Nagad", 
        "number": "01770530491", 
        "fee": 0,
        "type": "mobile",
        "min_amount": 0.20,
        "currency": "BDT"
    },
    "binance_id": {
        "name": "Binance ID", 
        "id": "763161979", 
        "fee": 0,
        "type": "binance_id",
        "min_amount": 0.20,
        "currency": "USD"
    },
    "usdt_trc20": {
        "name": "USDT (TRC20)", 
        "address": "TER79FYx6eLPnj8b716cBjaEEpsmewAa7X", 
        "fee": 0.01,
        "type": "crypto",
        "min_amount": 0.20,
        "currency": "USD"
    }
}

bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML")

# ================= DATABASE ================= #

db = sqlite3.connect("orange_bot.db", check_same_thread=False)
cursor = db.cursor()

cursor.execute("CREATE TABLE IF NOT EXISTS users(user_id INTEGER PRIMARY KEY, balance REAL DEFAULT 0, banned INTEGER DEFAULT 0, joined_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
cursor.execute("CREATE TABLE IF NOT EXISTS admins(user_id INTEGER PRIMARY KEY)")

cursor.execute("""
CREATE TABLE IF NOT EXISTS recharge(
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id INTEGER,
amount REAL,
method TEXT,
status TEXT DEFAULT 'Pending',
trx_id TEXT,
file_id TEXT,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS services(
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id INTEGER,
status TEXT,
end_time INTEGER,
reminded INTEGER DEFAULT 0)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS transactions(
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id INTEGER,
type TEXT,
amount REAL,
details TEXT,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)
""")

db.commit()

# ================= BASIC FUNCTIONS ================= #

def add_user(uid):
    cursor.execute("INSERT OR IGNORE INTO users(user_id) VALUES(?)", (uid,))
    db.commit()

def is_banned(uid):
    cursor.execute("SELECT banned FROM users WHERE user_id=?", (uid,))
    data = cursor.fetchone()
    return data and data[0] == 1

def get_balance(uid):
    cursor.execute("SELECT balance FROM users WHERE user_id=?", (uid,))
    data = cursor.fetchone()
    return data[0] if data else 0

def add_balance(uid, amount):
    cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id=?", (amount, uid))
    db.commit()
    # Log transaction
    cursor.execute("INSERT INTO transactions(user_id, type, amount, details) VALUES(?,?,?,?)",
                  (uid, "Deposit", amount, f"Balance added by system"))
    db.commit()

def is_admin(uid):
    if uid == SUPER_ADMIN:
        return True
    cursor.execute("SELECT user_id FROM admins WHERE user_id=?", (uid,))
    return cursor.fetchone() is not None

def animated(chat_id, text):
    bot.send_chat_action(chat_id, "typing")
    time.sleep(1)
    bot.send_message(chat_id, text)

def log_transaction(uid, trans_type, amount, details=""):
    cursor.execute("INSERT INTO transactions(user_id, type, amount, details) VALUES(?,?,?,?)",
                  (uid, trans_type, amount, details))
    db.commit()

def get_user_joined_date(uid):
    cursor.execute("SELECT joined_date FROM users WHERE user_id=?", (uid,))
    data = cursor.fetchone()
    return data[0] if data else datetime.now().strftime("%Y-%m-%d")

def bdt_to_usd(bdt_amount):
    return bdt_amount / BDT_TO_USD_RATE

def usd_to_bdt(usd_amount):
    return usd_amount * BDT_TO_USD_RATE

# ================= MAIN MENU ================= #

def main_menu():
    kb = ReplyKeyboardMarkup(resize_keyboard=True, row_width=3)
    kb.add("👤 Profile", "💰 Balance", "💳 Deposit Money")
    kb.add("🛒 Buy Service", "📦 My Services")
    kb.add("👑 Admin Panel")
    return kb

@bot.message_handler(commands=['start'])
def start(msg):
    add_user(msg.from_user.id)

    if is_banned(msg.from_user.id):
        bot.send_message(msg.chat.id, "⛔ You are banned.")
        return

    bot.send_message(msg.chat.id,
                     "<b>🔥 Orange Carrier Business Bot</b>",
                     reply_markup=main_menu())

# ================= PROFILE ================= #

@bot.message_handler(func=lambda m: m.text == "👤 Profile")
def profile(msg):
    if is_banned(msg.from_user.id):
        return

    user = msg.from_user
    uid = user.id
    
    # Get user info
    username = f"@{user.username}" if user.username else "Not set"
    full_name = f"{user.first_name} {user.last_name}" if user.last_name else user.first_name
    
    # Get active services count
    cursor.execute("SELECT COUNT(*) FROM services WHERE user_id=? AND status='Working'", (uid,))
    active_services = cursor.fetchone()[0]
    
    # Get completed services count
    cursor.execute("SELECT COUNT(*) FROM services WHERE user_id=? AND status='Done'", (uid,))
    completed_services = cursor.fetchone()[0]
    
    # Get joined date
    joined_date = get_user_joined_date(uid)
    
    text = f"""
<b>👤 Profile Information</b>
━━━━━━━━━━━━━━━━━━━━━
<b>🆔 User ID:</b> <code>{uid}</code>
<b>👤 Username:</b> {username}
<b>📛 Name:</b> {full_name}
<b>📦 Active Service:</b> {active_services}
<b>🌐 Total Completed:</b> {completed_services}
━━━━━━━━━━━━━━━━━━━━━
<b>📅 Joined:</b> {joined_date}
"""
    animated(msg.chat.id, text)

# ================= BALANCE MENU ================= #

@bot.message_handler(func=lambda m: m.text == "💰 Balance")
def balance_menu(msg):
    uid = msg.from_user.id
    if is_banned(uid):
        return
    
    bal = get_balance(uid)
    
    text = f"""
<b>💰 Account Balance</b>
━━━━━━━━━━━━━━━
<b>Current Balance:</b> <code>${bal:.2f}</code>
━━━━━━━━━━━━━━━
"""
    
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("💳 Deposit Money", callback_data="deposit"),
        InlineKeyboardButton("📊 Transaction History", callback_data="transactions")
    )
    kb.add(InlineKeyboardButton("🔙 Main Menu", callback_data="back_to_main"))
    
    bot.send_message(msg.chat.id, text, reply_markup=kb)

# ================= DIRECT DEPOSIT MENU ================= #

@bot.message_handler(func=lambda m: m.text == "💳 Deposit Money")
def direct_deposit(msg):
    uid = msg.from_user.id
    if is_banned(uid):
        return
    
    bal = get_balance(uid)
    
    text = f"""
<b>💳 Deposit Money</b>

<b>Exchange Rate:</b> 125 TK = 1$

<b>Choose Payment Method:</b>
• <b>bKash</b> - Mobile Banking (0% fee)
• <b>Nagad</b> - Mobile Banking (0% fee)  
• <b>Binance ID</b> - Binance Transfer (0% fee)
• <b>USDT (TRC20)</b> - Crypto (1% fee)

━━━━━━━━━━━━━━━
<b>Your Balance:</b> ${bal:.2f}
<b>Minimum Deposit:</b> $0.20
━━━━━━━━━━━━━━━
<i>Choose a payment method from below......</i>
"""
    
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("📱 bKash", callback_data="direct_deposit_bkash"),
        InlineKeyboardButton("📱 Nagad", callback_data="direct_deposit_nagad")
    )
    kb.add(
        InlineKeyboardButton("🆔 Binance ID", callback_data="direct_deposit_binance_id"),
        InlineKeyboardButton("₿ USDT (TRC20)", callback_data="direct_deposit_usdt_trc20")
    )
    kb.add(InlineKeyboardButton("🔙 Main Menu", callback_data="back_to_main_from_deposit"))
    
    bot.send_message(msg.chat.id, text, reply_markup=kb)

@bot.callback_query_handler(func=lambda c: c.data.startswith("direct_deposit_"))
def direct_deposit_details(c):
    method = c.data.replace("direct_deposit_", "")
    
    if method not in PAYMENT_METHODS:
        bot.answer_callback_query(c.id, "Invalid payment method")
        return
    
    pm = PAYMENT_METHODS[method]
    
    if method == "usdt_trc20":
        text = f"""
<b>₿ Deposit via USDT (TRC20)</b>
━━━━━━━━━━━━━━━
<b>Network:</b> TRC20 (Tron)
<b>Address:</b> <code>{pm['address']}</code>
<b>Fee:</b> {pm['fee']*100}%

<i>📝 Send USDT (TRC20) to above address</i>
<i>📸 After sending, forward the screenshot here</i>
<i>💰 Minimum deposit: ${pm['min_amount']:.2f}</i>
━━━━━━━━━━━━━━━
<b>Send amount in USD:</b>
"""
    elif method == "binance_id":
        text = f"""
<b>🆔 Deposit via Binance ID</b>
━━━━━━━━━━━━━━━
<b>Binance ID:</b> <code>{pm['id']}</code>
<b>Fee:</b> {pm['fee']*100}%

<i>📝 Send from your Binance account using Binance ID</i>
<i>📸 After sending, forward the screenshot here</i>
<i>💰 Minimum deposit: ${pm['min_amount']:.2f}</i>
━━━━━━━━━━━━━━━
<b>Send amount in USD:</b>
"""
    else:
        # bKash or Nagad
        bdt_min = usd_to_bdt(pm['min_amount'])
        text = f"""
<b>📱 Deposit via {pm['name']}</b>
━━━━━━━━━━━━━━━
<b>{pm['name']} Number:</b> <code>{pm['number']}</code>
<b>Fee:</b> {pm['fee']*100}%
<b>Exchange Rate:</b> 125 TK = 1$

<i>📝 Send money to above number</i>
<i>📸 After sending, forward the screenshot here</i>
<i>💾 Save Transaction ID (TRX)</i>
<i>💰 Minimum deposit: ${pm['min_amount']:.2f} ≈ {bdt_min:.0f} TK</i>
━━━━━━━━━━━━━━━
<b>Send amount in USD:</b>
<i>Or send amount in TK (automatically converted)</i>
"""
    
    msg = bot.send_message(c.message.chat.id, text)
    bot.register_next_step_handler(msg, process_deposit_amount, method)

def process_deposit_amount(msg, method):
    try:
        amount_text = msg.text.strip()
        
        # Check if amount contains "tk" or "TK" (for BDT)
        if amount_text.lower().endswith('tk'):
            # User sent amount in TK
            amount_bdt = float(amount_text[:-2].strip())
            amount_usd = bdt_to_usd(amount_bdt)
            
            # Convert back to show user
            converted_back = usd_to_bdt(amount_usd)
            bot.send_message(msg.chat.id, f"✅ {amount_bdt:.0f} TK ≈ ${amount_usd:.2f}")
        else:
            # User sent amount in USD
            amount_usd = float(amount_text)
            amount_bdt = usd_to_bdt(amount_usd)
        
        pm = PAYMENT_METHODS[method]
        
        if amount_usd < pm['min_amount']:
            if method in ["bkash", "nagad"]:
                bdt_min = usd_to_bdt(pm['min_amount'])
                bot.send_message(msg.chat.id, f"❌ Minimum deposit is ${pm['min_amount']:.2f} ≈ {bdt_min:.0f} TK")
            else:
                bot.send_message(msg.chat.id, f"❌ Minimum deposit is ${pm['min_amount']:.2f}")
            return
        
        # Calculate final amount after fee
        fee_amount = amount_usd * pm['fee']
        final_amount = amount_usd - fee_amount
        
        # Store temporary deposit data
        if method in ["bkash", "nagad"]:
            bot.send_message(msg.chat.id, f"✅ Amount set: ${amount_usd:.2f} ≈ {amount_bdt:.0f} TK")
        else:
            bot.send_message(msg.chat.id, f"✅ Amount set: ${amount_usd:.2f}")
        
        if fee_amount > 0:
            bot.send_message(msg.chat.id, f"📊 Fee ({pm['fee']*100}%): ${fee_amount:.2f}")
            bot.send_message(msg.chat.id, f"💰 You will receive: ${final_amount:.2f}")
        
        bot.send_message(msg.chat.id, "\nNow please send:")
        
        # Show payment instructions
        if method == "usdt_trc20":
            instructions = f"""
1. Send ${amount_usd:.2f} USDT (TRC20) to:
   <code>{pm['address']}</code>

2. Take a screenshot of transaction
3. Forward the screenshot here
4. We'll verify within 15 minutes
"""
        elif method == "binance_id":
            instructions = f"""
1. Send ${amount_usd:.2f} using Binance ID to:
   <code>{pm['id']}</code>

2. Take a screenshot of transaction
3. Forward the screenshot here
4. We'll verify within 15 minutes
"""
        else:
            # bKash or Nagad
            instructions = f"""
1. Send {amount_bdt:.0f} TK to {pm['name']}:
   <code>{pm['number']}</code>

2. Save Transaction ID (TRX)
3. Send TRX ID here
4. Take screenshot (optional)
5. We'll verify within 10 minutes
"""
        
        bot.send_message(msg.chat.id, instructions)
        
        # Ask for transaction proof
        if method in ["usdt_trc20", "binance_id"]:
            bot.send_message(msg.chat.id, "📸 Please forward the transaction screenshot:")
            expected_type = "screenshot"
        else:
            bot.send_message(msg.chat.id, "📝 Please send the Transaction ID (TRX):")
            expected_type = "trx_id"
        
        # Store amount data for next step
        user_data = {
            "amount_usd": amount_usd,
            "final_amount": final_amount,
            "fee_amount": fee_amount,
            "amount_bdt": amount_bdt if method in ["bkash", "nagad"] else None
        }
        
        bot.register_next_step_handler(msg, process_deposit_proof, method, user_data)
        
    except ValueError:
        bot.send_message(msg.chat.id, "❌ Invalid amount. Please send a number (e.g., 10, 10.50, or 1250tk)")

def process_deposit_proof(msg, method, user_data):
    uid = msg.from_user.id
    trx_id = None
    file_id = None
    
    pm = PAYMENT_METHODS[method]
    
    if method in ["usdt_trc20", "binance_id"]:
        # For crypto, expect photo
        if msg.photo:
            file_id = msg.photo[-1].file_id
            trx_id = f"{method.upper()}_{int(time.time())}"
            proof_type = "screenshot"
            proof_text = "Screenshot received"
        else:
            bot.send_message(msg.chat.id, "❌ Please send a screenshot photo")
            return
    else:
        # For bKash/Nagad, expect text (TRX ID)
        if msg.text:
            trx_id = msg.text.strip()
            file_id = None
            proof_type = "trx_id"
            proof_text = f"TRX ID: {trx_id}"
        else:
            bot.send_message(msg.chat.id, "❌ Please send the Transaction ID")
            return
    
    # Save to recharge table
    cursor.execute("""
        INSERT INTO recharge(user_id, amount, method, status, trx_id, file_id) 
        VALUES(?,?,?,?,?,?)
    """, (uid, user_data['amount_usd'], pm['name'], "Pending", trx_id, file_id))
    db.commit()
    
    recharge_id = cursor.lastrowid
    
    # Prepare user notification
    if method in ["bkash", "nagad"]:
        amount_info = f"${user_data['amount_usd']:.2f} ≈ {user_data['amount_bdt']:.0f} TK"
    else:
        amount_info = f"${user_data['amount_usd']:.2f}"
    
    text = f"""
✅ <b>Deposit Request Submitted</b>
━━━━━━━━━━━━━━━
<b>Amount:</b> {amount_info}
<b>Method:</b> {pm['name']}
"""
    
    if user_data['fee_amount'] > 0:
        text += f"<b>Fee ({pm['fee']*100}%):</b> ${user_data['fee_amount']:.2f}\n"
        text += f"<b>You will get:</b> ${user_data['final_amount']:.2f}\n"
    
    text += f"""
<b>Status:</b> ⏳ Pending
<b>Request ID:</b> <code>{recharge_id}</code>
<b>Proof:</b> {proof_text}
━━━━━━━━━━━━━━━
<i>Your deposit is under review. We'll notify you once approved.</i>
<i>Processing time: 10-15 minutes</i>
"""
    
    bot.send_message(msg.chat.id, text)
    
    # Notify admins
    notify_admins_about_deposit(uid, recharge_id, user_data['amount_usd'], pm['name'], trx_id, method, user_data)

def notify_admins_about_deposit(user_id, recharge_id, amount, method_name, trx_id, method_type, user_data):
    cursor.execute("SELECT user_id FROM admins")
    admins = cursor.fetchall()
    
    # Prepare admin notification
    text = f"""
🔔 <b>NEW DEPOSIT REQUEST</b>
━━━━━━━━━━━━━━━
<b>Request ID:</b> <code>{recharge_id}</code>
<b>User ID:</b> <code>{user_id}</code>
<b>Amount:</b> ${amount:.2f}
<b>Method:</b> {method_name}
"""
    
    if method_type in ["bkash", "nagad"]:
        text += f"<b>Amount in TK:</b> {user_data['amount_bdt']:.0f} TK\n"
    
    if user_data['fee_amount'] > 0:
        text += f"<b>Fee:</b> ${user_data['fee_amount']:.2f}\n"
        text += f"<b>Final Amount:</b> ${user_data['final_amount']:.2f}\n"
    
    text += f"""
<b>TRX/Proof:</b> <code>{trx_id}</code>
<b>Time:</b> {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
━━━━━━━━━━━━━━━
"""
    
    kb = InlineKeyboardMarkup()
    kb.add(
        InlineKeyboardButton("✅ Approve", callback_data=f"approve_deposit_{recharge_id}"),
        InlineKeyboardButton("❌ Reject", callback_data=f"reject_deposit_{recharge_id}")
    )
    
    for admin in admins:
        try:
            bot.send_message(admin[0], text, reply_markup=kb)
        except:
            pass
    
    # Notify SUPER_ADMIN too
    try:
        bot.send_message(SUPER_ADMIN, text, reply_markup=kb)
    except:
        pass

@bot.callback_query_handler(func=lambda c: c.data.startswith("approve_deposit_"))
def approve_deposit(c):
    if not is_admin(c.from_user.id):
        bot.answer_callback_query(c.id, "❌ Admin only")
        return
    
    recharge_id = int(c.data.replace("approve_deposit_", ""))
    
    # Get deposit details
    cursor.execute("SELECT user_id, amount, method FROM recharge WHERE id=? AND status='Pending'", (recharge_id,))
    deposit = cursor.fetchone()
    
    if not deposit:
        bot.answer_callback_query(c.id, "❌ Deposit not found or already processed")
        return
    
    user_id, amount, method = deposit
    
    # Calculate final amount (check if there was fee)
    pm = None
    for key, value in PAYMENT_METHODS.items():
        if value['name'] == method:
            pm = value
            break
    
    final_amount = amount
    if pm and pm['fee'] > 0:
        final_amount = amount * (1 - pm['fee'])
    
    # Update status
    cursor.execute("UPDATE recharge SET status='Approved' WHERE id=?", (recharge_id,))
    
    # Add balance (final amount after fee)
    add_balance(user_id, final_amount)
    
    # Log transaction
    log_transaction(user_id, "Deposit", final_amount, f"Via {method} #{recharge_id}")
    
    db.commit()
    
    # Notify user
    try:
        notification_text = f"""
✅ <b>Deposit Approved</b>
━━━━━━━━━━━━━━━
<b>Amount:</b> ${amount:.2f}
<b>Method:</b> {method}
"""
        
        if pm and pm['fee'] > 0:
            fee_amount = amount * pm['fee']
            notification_text += f"<b>Fee ({pm['fee']*100}%):</b> ${fee_amount:.2f}\n"
        
        notification_text += f"""
<b>Credited:</b> ${final_amount:.2f}
<b>Request ID:</b> <code>{recharge_id}</code>
<b>New Balance:</b> ${get_balance(user_id):.2f}
━━━━━━━━━━━━━━━
<i>Thank you for your deposit!</i>
"""
        
        bot.send_message(user_id, notification_text)
    except:
        pass
    
    # Update admin message
    bot.edit_message_text(
        f"✅ Deposit #{recharge_id} Approved by Admin\nAmount: ${final_amount:.2f} added to user balance",
        c.message.chat.id,
        c.message.id
    )
    
    bot.answer_callback_query(c.id, "✅ Deposit approved")

@bot.callback_query_handler(func=lambda c: c.data.startswith("reject_deposit_"))
def reject_deposit(c):
    if not is_admin(c.from_user.id):
        bot.answer_callback_query(c.id, "❌ Admin only")
        return
    
    recharge_id = int(c.data.replace("reject_deposit_", ""))
    
    # Get deposit details
    cursor.execute("SELECT user_id FROM recharge WHERE id=? AND status='Pending'", (recharge_id,))
    deposit = cursor.fetchone()
    
    if not deposit:
        bot.answer_callback_query(c.id, "❌ Deposit not found or already processed")
        return
    
    user_id = deposit[0]
    
    # Update status
    cursor.execute("UPDATE recharge SET status='Rejected' WHERE id=?", (recharge_id,))
    db.commit()
    
    # Notify user
    try:
        bot.send_message(user_id, f"""
❌ <b>Deposit Rejected</b>
━━━━━━━━━━━━━━━
<b>Request ID:</b> <code>{recharge_id}</code>
<b>Status:</b> Rejected
━━━━━━━━━━━━━━━
<i>Contact admin for more information.</i>
""")
    except:
        pass
    
    # Update admin message
    bot.edit_message_text(
        f"❌ Deposit #{recharge_id} Rejected by Admin",
        c.message.chat.id,
        c.message.id
    )
    
    bot.answer_callback_query(c.id, "❌ Deposit rejected")

@bot.callback_query_handler(func=lambda c: c.data == "back_to_main_from_deposit")
def back_to_main_from_deposit(c):
    bot.edit_message_text("<b>🔥 Orange Carrier Business Bot</b>", 
                         c.message.chat.id, c.message.id)
    bot.send_message(c.message.chat.id, "Main Menu:", reply_markup=main_menu())

# ================= BALANCE RELATED CALLBACKS ================= #

@bot.callback_query_handler(func=lambda c: c.data == "deposit")
def deposit_methods(c):
    uid = c.from_user.id
    bal = get_balance(uid)
    
    text = f"""
<b>💳 Deposit Money</b>

<b>Exchange Rate:</b> 125 TK = 1$

<b>Choose Payment Method:</b>
• <b>bKash</b> - Mobile Banking (0% fee)
• <b>Nagad</b> - Mobile Banking (0% fee)  
• <b>Binance ID</b> - Binance Transfer (0% fee)
• <b>USDT (TRC20)</b> - Crypto (1% fee)

━━━━━━━━━━━━━━━
<b>Your Balance:</b> ${bal:.2f}
<b>Minimum Deposit:</b> $0.20
━━━━━━━━━━━━━━━
<i>Choose a payment method from below......</i>
"""
    
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("📱 bKash", callback_data="deposit_bkash"),
        InlineKeyboardButton("📱 Nagad", callback_data="deposit_nagad")
    )
    kb.add(
        InlineKeyboardButton("🆔 Binance ID", callback_data="deposit_binance_id"),
        InlineKeyboardButton("₿ USDT (TRC20)", callback_data="deposit_usdt_trc20")
    )
    kb.add(InlineKeyboardButton("🔙 Back", callback_data="back_to_balance"))
    
    bot.edit_message_text(text, c.message.chat.id, c.message.id, reply_markup=kb)

@bot.callback_query_handler(func=lambda c: c.data.startswith("deposit_"))
def deposit_details(c):
    method = c.data.replace("deposit_", "")
    
    if method not in PAYMENT_METHODS:
        bot.answer_callback_query(c.id, "Invalid payment method")
        return
    
    pm = PAYMENT_METHODS[method]
    
    if method == "usdt_trc20":
        text = f"""
<b>₿ Deposit via USDT (TRC20)</b>
━━━━━━━━━━━━━━━
<b>Network:</b> TRC20 (Tron)
<b>Address:</b> <code>{pm['address']}</code>
<b>Fee:</b> {pm['fee']*100}%

<i>📝 Send USDT (TRC20) to above address</i>
<i>📸 After sending, forward the screenshot here</i>
<i>💰 Minimum deposit: ${pm['min_amount']:.2f}</i>
━━━━━━━━━━━━━━━
<b>Send amount in USD:</b>
"""
    elif method == "binance_id":
        text = f"""
<b>🆔 Deposit via Binance ID</b>
━━━━━━━━━━━━━━━
<b>Binance ID:</b> <code>{pm['id']}</code>
<b>Fee:</b> {pm['fee']*100}%

<i>📝 Send from your Binance account using Binance ID</i>
<i>📸 After sending, forward the screenshot here</i>
<i>💰 Minimum deposit: ${pm['min_amount']:.2f}</i>
━━━━━━━━━━━━━━━
<b>Send amount in USD:</b>
"""
    else:
        # bKash or Nagad
        bdt_min = usd_to_bdt(pm['min_amount'])
        text = f"""
<b>📱 Deposit via {pm['name']}</b>
━━━━━━━━━━━━━━━
<b>{pm['name']} Number:</b> <code>{pm['number']}</code>
<b>Fee:</b> {pm['fee']*100}%
<b>Exchange Rate:</b> 125 TK = 1$

<i>📝 Send money to above number</i>
<i>📸 After sending, forward the screenshot here</i>
<i>💾 Save Transaction ID (TRX)</i>
<i>💰 Minimum deposit: ${pm['min_amount']:.2f} ≈ {bdt_min:.0f} TK</i>
━━━━━━━━━━━━━━━
<b>Send amount in USD:</b>
<i>Or send amount in TK (automatically converted)</i>
"""
    
    msg = bot.send_message(c.message.chat.id, text)
    bot.register_next_step_handler(msg, process_deposit_amount, method)

@bot.callback_query_handler(func=lambda c: c.data == "transactions")
def transaction_history(c):
    uid = c.from_user.id
    
    cursor.execute("""
        SELECT type, amount, details, created_at 
        FROM transactions 
        WHERE user_id=? 
        ORDER BY created_at DESC 
        LIMIT 10
    """, (uid,))
    
    transactions = cursor.fetchall()
    
    if not transactions:
        text = "📊 <b>No transactions found</b>"
    else:
        text = "📊 <b>Recent Transactions</b>\n━━━━━━━━━━━━━━━\n"
        total_deposit = 0
        total_withdraw = 0
        
        for trans in transactions:
            trans_type, amount, details, created_at = trans
            
            if trans_type == "Deposit":
                total_deposit += amount
                icon = "📥"
            else:
                total_withdraw += amount
                icon = "📤"
            
            date_str = created_at.split()[0] if isinstance(created_at, str) else created_at
            text += f"{icon} <b>{trans_type}:</b> ${amount:.2f}\n"
            text += f"   <i>{details}</i>\n"
            text += f"   <code>{date_str}</code>\n\n"
        
        text += f"━━━━━━━━━━━━━━━\n"
        text += f"📥 Total Deposit: ${total_deposit:.2f}\n"
        text += f"📤 Total Withdraw: ${total_withdraw:.2f}\n"
    
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("🔙 Back", callback_data="back_to_balance"))
    
    bot.edit_message_text(text, c.message.chat.id, c.message.id, reply_markup=kb)

@bot.callback_query_handler(func=lambda c: c.data == "back_to_balance")
def back_to_balance(c):
    uid = c.from_user.id
    bal = get_balance(uid)
    
    text = f"""
<b>💰 Account Balance</b>
━━━━━━━━━━━━━━━
<b>Current Balance:</b> <code>${bal:.2f}</code>
━━━━━━━━━━━━━━━
"""
    
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("💳 Deposit Money", callback_data="deposit"),
        InlineKeyboardButton("📊 Transaction History", callback_data="transactions")
    )
    kb.add(InlineKeyboardButton("🔙 Main Menu", callback_data="back_to_main"))
    
    bot.edit_message_text(text, c.message.chat.id, c.message.id, reply_markup=kb)

@bot.callback_query_handler(func=lambda c: c.data == "back_to_main")
def back_to_main(c):
    text = "<b>🔥 Orange Carrier Business Bot</b>"
    bot.edit_message_text(text, c.message.chat.id, c.message.id)
    bot.send_message(c.message.chat.id, "Main Menu:", reply_markup=main_menu())

# ================= BUY SERVICE ================= #

@bot.message_handler(func=lambda m: m.text == "🛒 Buy Service")
def buy_service(msg):
    uid = msg.from_user.id

    if is_banned(uid):
        return

    if get_balance(uid) < SERVICE_PRICE:
        bot.send_message(msg.chat.id, "❌ Insufficient Balance")
        return

    add_balance(uid, -SERVICE_PRICE)
    log_transaction(uid, "Service Purchase", -SERVICE_PRICE, "6-hour service")

    cursor.execute("INSERT INTO services(user_id,status,end_time) VALUES(?,?,?)",
                   (uid, "Working", int(time.time()) + SERVICE_DURATION))
    db.commit()

    bot.send_message(msg.chat.id, "🚀 Service Activated (6 Hours)")

# ================= MY SERVICES ================= #

@bot.message_handler(func=lambda m: m.text == "📦 My Services")
def my_services(msg):
    cursor.execute("SELECT id,status FROM services WHERE user_id=?", (msg.from_user.id,))
    rows = cursor.fetchall()

    if not rows:
        bot.send_message(msg.chat.id, "No Services Found")
        return

    text = "<b>📦 Services:</b>\n\n"
    for r in rows:
        text += f"ID: {r[0]} | {r[1]}\n"

    bot.send_message(msg.chat.id, text)

# ================= ADMIN PANEL ================= #

@bot.message_handler(func=lambda m: m.text == "👑 Admin Panel")
def admin_panel(msg):
    if not is_admin(msg.from_user.id):
        return

    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("📊 Business Dashboard", callback_data="dash"),
        InlineKeyboardButton("💰 Edit Balance", callback_data="edit_bal")
    )
    kb.add(
        InlineKeyboardButton("🚫 Ban User", callback_data="ban"),
        InlineKeyboardButton("✅ Unban User", callback_data="unban")
    )
    kb.add(
        InlineKeyboardButton("💳 Deposit Requests", callback_data="view_deposits"),
        InlineKeyboardButton("📊 All Transactions", callback_data="all_transactions")
    )

    bot.send_message(msg.chat.id,
                     "<b>👑 ADMIN CONTROL PANEL</b>",
                     reply_markup=kb)

@bot.callback_query_handler(func=lambda c: c.data == "view_deposits")
def view_deposits(c):
    if not is_admin(c.from_user.id):
        bot.answer_callback_query(c.id, "❌ Admin only")
        return
    
    cursor.execute("""
        SELECT r.id, r.user_id, r.amount, r.method, r.status, r.created_at, u.banned 
        FROM recharge r 
        LEFT JOIN users u ON r.user_id = u.user_id 
        WHERE r.status='Pending'
        ORDER BY r.created_at DESC
        LIMIT 20
    """)
    
    deposits = cursor.fetchall()
    
    if not deposits:
        text = "📋 <b>No pending deposits</b>"
    else:
        text = "📋 <b>Pending Deposit Requests</b>\n━━━━━━━━━━━━━━━\n"
        
        for dep in deposits:
            dep_id, user_id, amount, method, status, created_at, banned = dep
            ban_status = "🚫" if banned else "✅"
            
            date_str = created_at.split()[0] if isinstance(created_at, str) else created_at
            
            text += f"<b>ID:</b> <code>{dep_id}</code>\n"
            text += f"<b>User:</b> <code>{user_id}</code> {ban_status}\n"
            text += f"<b>Amount:</b> ${amount:.2f}\n"
            text += f"<b>Method:</b> {method}\n"
            text += f"<b>Date:</b> {date_str}\n"
            
            kb = InlineKeyboardMarkup(row_width=2)
            kb.add(
                InlineKeyboardButton("✅ Approve", callback_data=f"approve_deposit_{dep_id}"),
                InlineKeyboardButton("❌ Reject", callback_data=f"reject_deposit_{dep_id}")
            )
            
            text += "━━━━━━━━━━━━━━━\n"
    
    kb_back = InlineKeyboardMarkup()
    kb_back.add(InlineKeyboardButton("🔙 Back", callback_data="back_to_admin"))
    
    if 'deposits' in locals() and deposits:
        # If there are deposits, we need to handle differently
        # For simplicity, just show first deposit with buttons
        if deposits:
            dep = deposits[0]
            dep_id, user_id, amount, method, status, created_at, banned = dep
            
            text = f"""
📋 <b>Deposit Request #{dep_id}</b>
━━━━━━━━━━━━━━━
<b>User ID:</b> <code>{user_id}</code>
<b>Amount:</b> ${amount:.2f}
<b>Method:</b> {method}
<b>Status:</b> {status}
<b>Date:</b> {created_at}
━━━━━━━━━━━━━━━
"""
            
            kb = InlineKeyboardMarkup(row_width=2)
            kb.add(
                InlineKeyboardButton("✅ Approve", callback_data=f"approve_deposit_{dep_id}"),
                InlineKeyboardButton("❌ Reject", callback_data=f"reject_deposit_{dep_id}")
            )
            kb.add(InlineKeyboardButton("🔙 Back", callback_data="back_to_admin"))
            
            bot.edit_message_text(text, c.message.chat.id, c.message.id, reply_markup=kb)
            return
    
    bot.edit_message_text(text, c.message.chat.id, c.message.id, reply_markup=kb_back)

@bot.callback_query_handler(func=lambda c: c.data == "all_transactions")
def all_transactions(c):
    if not is_admin(c.from_user.id):
        bot.answer_callback_query(c.id, "❌ Admin only")
        return
    
    cursor.execute("""
        SELECT user_id, type, amount, details, created_at 
        FROM transactions 
        ORDER BY created_at DESC 
        LIMIT 20
    """)
    
    transactions = cursor.fetchall()
    
    if not transactions:
        text = "📊 <b>No transactions found</b>"
    else:
        text = "📊 <b>All Transactions (Last 20)</b>\n━━━━━━━━━━━━━━━\n"
        
        total = 0
        
        for trans in transactions:
            user_id, trans_type, amount, details, created_at = trans
            total += amount if trans_type == "Deposit" else -amount
            
            icon = "📥" if trans_type == "Deposit" else "📤"
            sign = "+" if trans_type == "Deposit" else "-"
            
            date_str = created_at.split()[0] if isinstance(created_at, str) else created_at
            
            text += f"{icon} <code>{user_id}</code> | {sign}${abs(amount):.2f}\n"
            text += f"   <i>{details[:30]}...</i>\n"
            text += f"   <code>{date_str}</code>\n\n"
        
        text += f"━━━━━━━━━━━━━━━\n"
        text += f"💰 <b>Net Total:</b> ${total:.2f}\n"
    
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("🔙 Back", callback_data="back_to_admin"))
    
    bot.edit_message_text(text, c.message.chat.id, c.message.id, reply_markup=kb)

@bot.callback_query_handler(func=lambda c: c.data == "back_to_admin")
def back_to_admin(c):
    if not is_admin(c.from_user.id):
        return
    
    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("📊 Business Dashboard", callback_data="dash"),
        InlineKeyboardButton("💰 Edit Balance", callback_data="edit_bal")
    )
    kb.add(
        InlineKeyboardButton("🚫 Ban User", callback_data="ban"),
        InlineKeyboardButton("✅ Unban User", callback_data="unban")
    )
    kb.add(
        InlineKeyboardButton("💳 Deposit Requests", callback_data="view_deposits"),
        InlineKeyboardButton("📊 All Transactions", callback_data="all_transactions")
    )
    
    bot.edit_message_text("<b>👑 ADMIN CONTROL PANEL</b>", 
                         c.message.chat.id, c.message.id, reply_markup=kb)

# ================= BUSINESS DASHBOARD ================= #

@bot.callback_query_handler(func=lambda c: c.data == "dash")
def dashboard(c):
    cursor.execute("SELECT COUNT(*) FROM users")
    users = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM services WHERE status='Working'")
    active = cursor.fetchone()[0]

    cursor.execute("SELECT SUM(balance) FROM users")
    total_balance = cursor.fetchone()[0] or 0
    
    cursor.execute("SELECT SUM(amount) FROM recharge WHERE status='Approved'")
    total_deposits = cursor.fetchone()[0] or 0
    
    cursor.execute("SELECT COUNT(*) FROM recharge WHERE status='Pending'")
    pending_deposits = cursor.fetchone()[0]

    text = f"""
<b>📊 BUSINESS DASHBOARD</b>
━━━━━━━━━━━━━━━
👥 Total Users: {users}
🚀 Active Services: {active}
💰 Total User Balance: ${total_balance:.2f}
📥 Total Deposits: ${total_deposits:.2f}
⏳ Pending Deposits: {pending_deposits}
━━━━━━━━━━━━━━━
"""
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("🔙 Back", callback_data="back_to_admin"))
    
    bot.edit_message_text(text, c.message.chat.id, c.message.id, reply_markup=kb)

# ================= BAN SYSTEM ================= #

@bot.callback_query_handler(func=lambda c: c.data == "ban")
def ban_user_prompt(c):
    msg = bot.send_message(c.message.chat.id, "Send User ID to Ban")
    bot.register_next_step_handler(msg, ban_user)

def ban_user(msg):
    try:
        uid = int(msg.text)
        cursor.execute("UPDATE users SET banned=1 WHERE user_id=?", (uid,))
        db.commit()
        
        # Try to notify user
        try:
            bot.send_message(uid, "⛔ You have been banned from the bot.")
        except:
            pass
            
        bot.send_message(msg.chat.id, "✅ User Banned")
    except:
        bot.send_message(msg.chat.id, "❌ Invalid User ID")

@bot.callback_query_handler(func=lambda c: c.data == "unban")
def unban_prompt(c):
    msg = bot.send_message(c.message.chat.id, "Send User ID to Unban")
    bot.register_next_step_handler(msg, unban_user)

def unban_user(msg):
    try:
        uid = int(msg.text)
        cursor.execute("UPDATE users SET banned=0 WHERE user_id=?", (uid,))
        db.commit()
        
        # Try to notify user
        try:
            bot.send_message(uid, "✅ You have been unbanned from the bot.")
        except:
            pass
            
        bot.send_message(msg.chat.id, "✅ User Unbanned")
    except:
        bot.send_message(msg.chat.id, "❌ Invalid User ID")

# ================= EDIT BALANCE ================= #

@bot.callback_query_handler(func=lambda c: c.data == "edit_bal")
def edit_balance_prompt(c):
    msg = bot.send_message(c.message.chat.id, "Send: user_id amount\nExample: 123456789 10")
    bot.register_next_step_handler(msg, edit_balance)

def edit_balance(msg):
    try:
        uid, amount = msg.text.split()
        add_balance(int(uid), float(amount))
        bot.send_message(msg.chat.id, "✅ Balance Updated")
    except:
        bot.send_message(msg.chat.id, "❌ Invalid Format")

# ================= AUTO TIMER + REMINDER ================= #

def service_timer():
    while True:
        now = int(time.time())

        cursor.execute("SELECT id,user_id,end_time,reminded FROM services WHERE status='Working'")
        rows = cursor.fetchall()

        for sid, uid, end_time, reminded in rows:

            # Reminder
            if end_time - now <= REMINDER_TIME and reminded == 0:
                bot.send_message(uid, "⏳ Your service will expire in 1 hour.")
                cursor.execute("UPDATE services SET reminded=1 WHERE id=?", (sid,))
                db.commit()

            # Expired
            if now >= end_time:
                cursor.execute("UPDATE services SET status='Done' WHERE id=?", (sid,))
                db.commit()
                bot.send_message(uid, "✅ Service Completed")

        time.sleep(30)

threading.Thread(target=service_timer, daemon=True).start()

# ================= RUN ================= #

print("🔥 ENTERPRISE BOT RUNNING...")
bot.infinity_polling()
[file content end]