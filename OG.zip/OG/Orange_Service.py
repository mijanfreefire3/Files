import telebot
from telebot.types import *
import sqlite3
import time
import threading

# ================= CONFIG ================= #

BOT_TOKEN = "8534858301:AAFSDBBImHGjlWoq73Up1khezTF00YSHyVE"
SUPER_ADMIN = 5556053750  # তোমার Telegram ID

bot = telebot.TeleBot(BOT_TOKEN)

# ================= DATABASE ================= #

db = sqlite3.connect("orange_bot.db", check_same_thread=False)
cursor = db.cursor()

cursor.execute("CREATE TABLE IF NOT EXISTS users(user_id INTEGER PRIMARY KEY, balance REAL DEFAULT 0)")
cursor.execute("CREATE TABLE IF NOT EXISTS admins(user_id INTEGER PRIMARY KEY)")
cursor.execute("""CREATE TABLE IF NOT EXISTS recharge(
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id INTEGER,
amount REAL,
status TEXT,
file_id TEXT)""")

cursor.execute("""CREATE TABLE IF NOT EXISTS services(
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id INTEGER,
email TEXT,
username TEXT,
bot_username TEXT,
chat_id TEXT,
status TEXT,
end_time INTEGER)""")

db.commit()

# ================= BASIC FUNCTIONS ================= #

def add_user(uid):
    cursor.execute("INSERT OR IGNORE INTO users(user_id) VALUES(?)", (uid,))
    db.commit()

def get_balance(uid):
    cursor.execute("SELECT balance FROM users WHERE user_id=?", (uid,))
    return cursor.fetchone()[0]

def add_balance(uid, amount):
    cursor.execute("UPDATE users SET balance=balance+? WHERE user_id=?", (amount, uid))
    db.commit()

def is_admin(uid):
    if uid == SUPER_ADMIN:
        return True
    cursor.execute("SELECT user_id FROM admins WHERE user_id=?", (uid,))
    return cursor.fetchone() is not None

# ================= START ================= #

@bot.message_handler(commands=['start'])
def start(msg):
    add_user(msg.from_user.id)

    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("📊 Dashboard", callback_data="dashboard"))
    kb.add(InlineKeyboardButton("🛒 Buy Service", callback_data="buy"))
    kb.add(InlineKeyboardButton("💰 Recharge", callback_data="recharge"))

    bot.send_message(msg.chat.id, "👋 Welcome Orange Carrier Rent Bot", reply_markup=kb)

# ================= DASHBOARD ================= #

@bot.callback_query_handler(func=lambda c: c.data == "dashboard")
def dashboard(c):
    bal = get_balance(c.from_user.id)

    bot.edit_message_text(
        f"📊 Dashboard\n\n💰 Balance: ${bal:.2f}",
        c.message.chat.id,
        c.message.id
    )

# ================= RECHARGE ================= #

user_recharge = {}

@bot.callback_query_handler(func=lambda c: c.data == "recharge")
def recharge(c):
    msg = bot.send_message(c.message.chat.id, "Enter Recharge Amount ($)")
    bot.register_next_step_handler(msg, recharge_amount)

def recharge_amount(msg):
    try:
        amount = float(msg.text)
        user_recharge[msg.from_user.id] = amount
        bot.send_message(msg.chat.id, "📤 Send Payment Screenshot")
    except:
        bot.send_message(msg.chat.id, "Invalid Amount")

@bot.message_handler(content_types=['photo'])
def recharge_screenshot(msg):

    if msg.from_user.id not in user_recharge:
        return

    amount = user_recharge[msg.from_user.id]
    file_id = msg.photo[-1].file_id

    cursor.execute(
        "INSERT INTO recharge(user_id,amount,status,file_id) VALUES(?,?,?,?)",
        (msg.from_user.id, amount, "Pending", file_id)
    )
    db.commit()

    rid = cursor.lastrowid

    kb = InlineKeyboardMarkup()
    kb.add(
        InlineKeyboardButton("✅ Approve", callback_data=f"approve_{rid}"),
        InlineKeyboardButton("❌ Reject", callback_data=f"reject_{rid}")
    )

    bot.send_photo(
        SUPER_ADMIN,
        file_id,
        caption=f"Recharge Request\nUser: {msg.from_user.id}\nAmount: ${amount}",
        reply_markup=kb
    )

    bot.send_message(msg.chat.id, "✅ Recharge Submitted")
    del user_recharge[msg.from_user.id]

# ================= RECHARGE APPROVE ================= #

@bot.callback_query_handler(func=lambda c: c.data.startswith("approve_"))
def approve_recharge(c):

    if not is_admin(c.from_user.id):
        return

    rid = c.data.split("_")[1]

    cursor.execute("SELECT user_id,amount FROM recharge WHERE id=?", (rid,))
    user_id, amount = cursor.fetchone()

    add_balance(user_id, amount)
    cursor.execute("UPDATE recharge SET status='Approved' WHERE id=?", (rid,))
    db.commit()

    bot.send_message(user_id, f"✅ Recharge Approved: ${amount}")

@bot.callback_query_handler(func=lambda c: c.data.startswith("reject_"))
def reject_recharge(c):

    if not is_admin(c.from_user.id):
        return

    rid = c.data.split("_")[1]
    cursor.execute("UPDATE recharge SET status='Rejected' WHERE id=?", (rid,))
    db.commit()

# ================= BUY SERVICE ================= #

service_data = {}

@bot.callback_query_handler(func=lambda c: c.data == "buy")
def buy_service(c):

    if get_balance(c.from_user.id) < 0.02:
        bot.answer_callback_query(c.id, "Insufficient Balance")
        return

    msg = bot.send_message(c.message.chat.id, "Orange Carrier Email:")
    bot.register_next_step_handler(msg, step_email)

def step_email(msg):
    service_data[msg.from_user.id] = {"email": msg.text}
    msg2 = bot.send_message(msg.chat.id, "Your Username:")
    bot.register_next_step_handler(msg2, step_username)

def step_username(msg):
    service_data[msg.from_user.id]["username"] = msg.text
    msg2 = bot.send_message(msg.chat.id, "Your Bot Username:")
    bot.register_next_step_handler(msg2, step_bot)

def step_bot(msg):
    service_data[msg.from_user.id]["bot"] = msg.text
    msg2 = bot.send_message(msg.chat.id, "Group Chat ID:")
    bot.register_next_step_handler(msg2, finish_service)

def finish_service(msg):

    add_balance(msg.from_user.id, -0.02)

    data = service_data[msg.from_user.id]

    cursor.execute("""
    INSERT INTO services(user_id,email,username,bot_username,chat_id,status,end_time)
    VALUES(?,?,?,?,?,?,?)
    """, (
        msg.from_user.id,
        data["email"],
        data["username"],
        data["bot"],
        msg.text,
        "Pending",
        0
    ))

    db.commit()

    sid = cursor.lastrowid

    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton("🚀 Start Service", callback_data=f"start_{sid}"))

    bot.send_message(SUPER_ADMIN, f"New Service Request #{sid}", reply_markup=kb)
    bot.send_message(msg.chat.id, "✅ Request Submitted")

# ================= START SERVICE ================= #

@bot.callback_query_handler(func=lambda c: c.data.startswith("start_"))
def start_service(c):

    if not is_admin(c.from_user.id):
        return

    sid = c.data.split("_")[1]
    end_time = int(time.time()) + 21600

    cursor.execute("UPDATE services SET status='Working', end_time=? WHERE id=?", (end_time, sid))
    db.commit()

    cursor.execute("SELECT user_id FROM services WHERE id=?", (sid,))
    uid = cursor.fetchone()[0]

    bot.send_message(uid, "🚀 Service Started (6 Hours)")

# ================= AUTO TIMER ================= #

def service_timer():
    while True:
        now = int(time.time())

        cursor.execute("SELECT id,user_id FROM services WHERE status='Working' AND end_time<?", (now,))
        rows = cursor.fetchall()

        for sid, uid in rows:
            cursor.execute("UPDATE services SET status='Done' WHERE id=?", (sid,))
            db.commit()

            bot.send_message(uid, "✅ Service Completed")

        time.sleep(30)

threading.Thread(target=service_timer).start()

# ================= SUPER ADMIN PANEL ================= #

@bot.message_handler(commands=['superadmin'])
def super_admin(msg):

    if msg.from_user.id != SUPER_ADMIN:
        return

    kb = InlineKeyboardMarkup(row_width=2)

    kb.add(
        InlineKeyboardButton("👥 Users", callback_data="sa_users"),
        InlineKeyboardButton("📦 Services", callback_data="sa_services")
    )

    kb.add(
        InlineKeyboardButton("📢 Broadcast", callback_data="sa_bc"),
        InlineKeyboardButton("➕ Add Admin", callback_data="sa_add")
    )

    bot.send_message(msg.chat.id, "👑 Super Admin Panel", reply_markup=kb)

# USERS COUNT
@bot.callback_query_handler(func=lambda c: c.data == "sa_users")
def sa_users(c):
    cursor.execute("SELECT COUNT(*) FROM users")
    bot.send_message(c.message.chat.id, f"👥 Users: {cursor.fetchone()[0]}")

# SERVICES COUNT
@bot.callback_query_handler(func=lambda c: c.data == "sa_services")
def sa_services(c):
    cursor.execute("SELECT COUNT(*) FROM services")
    bot.send_message(c.message.chat.id, f"📦 Services: {cursor.fetchone()[0]}")

# ADD ADMIN
@bot.callback_query_handler(func=lambda c: c.data == "sa_add")
def sa_add(c):
    msg = bot.send_message(c.message.chat.id, "Send User ID")
    bot.register_next_step_handler(msg, add_admin_step)

def add_admin_step(msg):
    cursor.execute("INSERT OR IGNORE INTO admins VALUES(?)", (int(msg.text),))
    db.commit()
    bot.send_message(msg.chat.id, "✅ Admin Added")

# BROADCAST
@bot.callback_query_handler(func=lambda c: c.data == "sa_bc")
def sa_bc(c):
    msg = bot.send_message(c.message.chat.id, "Send Broadcast Message")
    bot.register_next_step_handler(msg, send_bc)

def send_bc(msg):
    cursor.execute("SELECT user_id FROM users")
    users = cursor.fetchall()

    for u in users:
        try:
            bot.send_message(u[0], msg.text)
        except:
            pass

    bot.send_message(msg.chat.id, "✅ Broadcast Sent")

# ================= RUN ================= #

print("BOT RUNNING...")
bot.infinity_polling()