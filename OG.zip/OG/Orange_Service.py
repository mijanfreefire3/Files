import telebot
from telebot.types import *
import sqlite3
import time
import threading
import os

# ================= CONFIG ================= #

BOT_TOKEN = os.getenv("8534858301:AAFSDBBImHGjlWoq73Up1khezTF00YSHyVE")
SUPER_ADMIN = 5556053750
SERVICE_PRICE = 0.02
SERVICE_DURATION = 21600
REMINDER_TIME = 3600  # 1 hour before expiry

bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML")

# ================= DATABASE ================= #

db = sqlite3.connect("orange_bot.db", check_same_thread=False)
cursor = db.cursor()

cursor.execute("CREATE TABLE IF NOT EXISTS users(user_id INTEGER PRIMARY KEY, balance REAL DEFAULT 0, banned INTEGER DEFAULT 0)")
cursor.execute("CREATE TABLE IF NOT EXISTS admins(user_id INTEGER PRIMARY KEY)")

cursor.execute("""
CREATE TABLE IF NOT EXISTS recharge(
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id INTEGER,
amount REAL,
status TEXT,
file_id TEXT)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS services(
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id INTEGER,
status TEXT,
end_time INTEGER,
reminded INTEGER DEFAULT 0)
""")

db.commit()

# ================= BASIC FUNCTIONS ================= #

def add_user(uid):
    cursor.execute("INSERT OR IGNORE INTO users(user_id) VALUES(?)", (uid,))
    db.commit()

def is_banned(uid):
    cursor.execute("SELECT banned FROM users WHERE user_id=?", (uid,))
    data = cursor.fetchone()
    return data and data[0] == 1

def get_balance(uid):
    cursor.execute("SELECT balance FROM users WHERE user_id=?", (uid,))
    data = cursor.fetchone()
    return data[0] if data else 0

def add_balance(uid, amount):
    cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id=?", (amount, uid))
    db.commit()

def is_admin(uid):
    if uid == SUPER_ADMIN:
        return True
    cursor.execute("SELECT user_id FROM admins WHERE user_id=?", (uid,))
    return cursor.fetchone() is not None

def animated(chat_id, text):
    bot.send_chat_action(chat_id, "typing")
    time.sleep(1)
    bot.send_message(chat_id, text)

# ================= MAIN MENU ================= #

def main_menu():
    kb = ReplyKeyboardMarkup(resize_keyboard=True)
    kb.add("👤 Profile", "💰 Balance")
    kb.add("🛒 Buy Service", "📦 My Services")
    kb.add("👑 Admin Panel")
    return kb

@bot.message_handler(commands=['start'])
def start(msg):
    add_user(msg.from_user.id)

    if is_banned(msg.from_user.id):
        bot.send_message(msg.chat.id, "⛔ You are banned.")
        return

    bot.send_message(msg.chat.id,
                     "<b>🔥 Orange Carrier Business Bot</b>",
                     reply_markup=main_menu())

# ================= PROFILE ================= #

@bot.message_handler(func=lambda m: m.text == "👤 Profile")
def profile(msg):
    if is_banned(msg.from_user.id):
        return

    bal = get_balance(msg.from_user.id)

    cursor.execute("SELECT COUNT(*) FROM services WHERE user_id=? AND status='Working'", (msg.from_user.id,))
    active = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM services WHERE user_id=? AND status='Done'", (msg.from_user.id,))
    done = cursor.fetchone()[0]

    text = f"""
<b>👤 USER PROFILE</b>
━━━━━━━━━━━━━━━
<b>ID:</b> <code>{msg.from_user.id}</code>
<b>Balance:</b> ${bal:.2f}
<b>Active:</b> {active}
<b>Completed:</b> {done}
━━━━━━━━━━━━━━━
"""
    animated(msg.chat.id, text)

# ================= BUY SERVICE ================= #

@bot.message_handler(func=lambda m: m.text == "🛒 Buy Service")
def buy_service(msg):
    uid = msg.from_user.id

    if is_banned(uid):
        return

    if get_balance(uid) < SERVICE_PRICE:
        bot.send_message(msg.chat.id, "❌ Insufficient Balance")
        return

    add_balance(uid, -SERVICE_PRICE)

    cursor.execute("INSERT INTO services(user_id,status,end_time) VALUES(?,?,?)",
                   (uid, "Working", int(time.time()) + SERVICE_DURATION))
    db.commit()

    bot.send_message(msg.chat.id, "🚀 Service Activated (6 Hours)")

# ================= MY SERVICES ================= #

@bot.message_handler(func=lambda m: m.text == "📦 My Services")
def my_services(msg):
    cursor.execute("SELECT id,status FROM services WHERE user_id=?", (msg.from_user.id,))
    rows = cursor.fetchall()

    if not rows:
        bot.send_message(msg.chat.id, "No Services Found")
        return

    text = "<b>📦 Services:</b>\n\n"
    for r in rows:
        text += f"ID: {r[0]} | {r[1]}\n"

    bot.send_message(msg.chat.id, text)

# ================= ADMIN PANEL ================= #

@bot.message_handler(func=lambda m: m.text == "👑 Admin Panel")
def admin_panel(msg):
    if not is_admin(msg.from_user.id):
        return

    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("📊 Business Dashboard", callback_data="dash"),
        InlineKeyboardButton("💰 Edit Balance", callback_data="edit_bal")
    )
    kb.add(
        InlineKeyboardButton("🚫 Ban User", callback_data="ban"),
        InlineKeyboardButton("✅ Unban User", callback_data="unban")
    )

    bot.send_message(msg.chat.id,
                     "<b>👑 ADMIN CONTROL PANEL</b>",
                     reply_markup=kb)

# ================= BUSINESS DASHBOARD ================= #

@bot.callback_query_handler(func=lambda c: c.data == "dash")
def dashboard(c):
    cursor.execute("SELECT COUNT(*) FROM users")
    users = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM services WHERE status='Working'")
    active = cursor.fetchone()[0]

    cursor.execute("SELECT SUM(balance) FROM users")
    total_balance = cursor.fetchone()[0] or 0

    text = f"""
<b>📊 BUSINESS DASHBOARD</b>
━━━━━━━━━━━━━━━
👥 Total Users: {users}
🚀 Active Services: {active}
💰 Total User Balance: ${total_balance:.2f}
━━━━━━━━━━━━━━━
"""
    bot.edit_message_text(text, c.message.chat.id, c.message.id)

# ================= BAN SYSTEM ================= #

@bot.callback_query_handler(func=lambda c: c.data == "ban")
def ban_user_prompt(c):
    msg = bot.send_message(c.message.chat.id, "Send User ID to Ban")
    bot.register_next_step_handler(msg, ban_user)

def ban_user(msg):
    cursor.execute("UPDATE users SET banned=1 WHERE user_id=?", (msg.text,))
    db.commit()
    bot.send_message(msg.chat.id, "✅ User Banned")

@bot.callback_query_handler(func=lambda c: c.data == "unban")
def unban_prompt(c):
    msg = bot.send_message(c.message.chat.id, "Send User ID to Unban")
    bot.register_next_step_handler(msg, unban_user)

def unban_user(msg):
    cursor.execute("UPDATE users SET banned=0 WHERE user_id=?", (msg.text,))
    db.commit()
    bot.send_message(msg.chat.id, "✅ User Unbanned")

# ================= EDIT BALANCE ================= #

@bot.callback_query_handler(func=lambda c: c.data == "edit_bal")
def edit_balance_prompt(c):
    msg = bot.send_message(c.message.chat.id, "Send: user_id amount\nExample: 123456789 10")
    bot.register_next_step_handler(msg, edit_balance)

def edit_balance(msg):
    try:
        uid, amount = msg.text.split()
        add_balance(int(uid), float(amount))
        bot.send_message(msg.chat.id, "✅ Balance Updated")
    except:
        bot.send_message(msg.chat.id, "❌ Invalid Format")

# ================= AUTO TIMER + REMINDER ================= #

def service_timer():
    while True:
        now = int(time.time())

        cursor.execute("SELECT id,user_id,end_time,reminded FROM services WHERE status='Working'")
        rows = cursor.fetchall()

        for sid, uid, end_time, reminded in rows:

            # Reminder
            if end_time - now <= REMINDER_TIME and reminded == 0:
                bot.send_message(uid, "⏳ Your service will expire in 1 hour.")
                cursor.execute("UPDATE services SET reminded=1 WHERE id=?", (sid,))
                db.commit()

            # Expired
            if now >= end_time:
                cursor.execute("UPDATE services SET status='Done' WHERE id=?", (sid,))
                db.commit()
                bot.send_message(uid, "✅ Service Completed")

        time.sleep(30)

threading.Thread(target=service_timer, daemon=True).start()

# ================= RUN ================= #

print("🔥 ENTERPRISE BOT RUNNING...")
bot.infinity_polling()